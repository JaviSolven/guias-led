@echo off
rem Asistente para usar DOS tiras con el mismo puente: la de los lados del monitor
rem y la barra de abajo. Reconoce cada tira, elige los tramos de la barra y crea tiras.txt.
rem Si tienes el servicio instalado, ejecutalo con clic derecho - Ejecutar como administrador.
cd /d "%~dp0"
title Configurar las dos tiras
echo.
echo   CONFIGURAR LAS DOS TIRAS (lados del monitor + barra de abajo)
echo   ------------------------------------------------------------
echo   - Enchufa las dos tiras, cada una en su USB de la torre.
echo   - Cierra DX Light si estuviera abierto.
echo.
set "SERVICIO=PuenteHyperionRobobloq"
set "VOLVER="
sc query %SERVICIO% 2>nul | "%SystemRoot%\System32\find.exe" "RUNNING" >nul
if errorlevel 1 goto sin_servicio
echo   El servicio del puente esta en marcha: lo paro mientras configuras...
sc stop %SERVICIO% >nul 2>&1
if errorlevel 1 goto sin_permiso
set "VOLVER=1"
ping -n 8 127.0.0.1 >nul
:sin_servicio
powershell -NoProfile -ExecutionPolicy Bypass -Command "$p=Get-CimInstance Win32_Process | Where-Object { $_.Name -like 'py*' -and $_.CommandLine -like '*robobloq_bridge.py*' }; foreach ($x in $p) { Stop-Process -Id $x.ProcessId -Force -ErrorAction SilentlyContinue }; if (@($p).Count) { '   Cerrado el puente que estaba abierto.' }"
py -3 robobloq_bridge.py --configurar
if not defined VOLVER goto fin
echo.
echo   Vuelvo a arrancar el servicio del puente...
sc start %SERVICIO% >nul 2>&1
goto fin
:sin_permiso
echo.
echo   No he podido parar el servicio. Cierra esta ventana y ejecuta este
echo   fichero con clic derecho - Ejecutar como administrador.
:fin
echo.
echo   Si usas el arranque al iniciar sesion en vez del servicio, vuelve a
echo   ejecutar arranque_automatico.bat o reinicia el PC.
echo.
pause
