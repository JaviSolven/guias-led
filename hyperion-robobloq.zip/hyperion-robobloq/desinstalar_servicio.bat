@echo off
rem Para y quita el servicio "Puente Hyperion Robobloq".
rem Ejecutar con boton derecho -> "Ejecutar como administrador".
set "SERVICIO=PuenteHyperionRobobloq"
net session >nul 2>&1
if errorlevel 1 (
  echo Hay que ejecutarlo como administrador: boton derecho, "Ejecutar como administrador".
  pause
  exit /b 1
)
sc query %SERVICIO% >nul 2>&1
if errorlevel 1 (
  echo El servicio no estaba instalado.
  pause
  exit /b 0
)
echo Parando el servicio (la tira se apaga)...
sc stop %SERVICIO% >nul 2>&1
ping -n 9 127.0.0.1 >nul
sc delete %SERVICIO% >nul
if errorlevel 1 (
  echo No se pudo quitar. Reinicia el PC y vuelve a probar.
  pause
  exit /b 1
)
echo Servicio quitado. Para volver a tenerlo: instalar_servicio.bat
pause
