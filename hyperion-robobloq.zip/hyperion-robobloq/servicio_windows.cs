// Lanzador del puente como servicio de Windows.
//
// instalar_servicio.bat lo compila con el compilador de .NET que trae Windows
// (csc.exe) y lo registra como servicio «Puente Hyperion Robobloq».
//
// Qué hace:
//   - Al arrancar el servicio, lanza pythonw.exe robobloq_bridge.py (sin ventana)
//     con las opciones de servicio.cfg y el registro en puente.log.
//   - Si el puente termina por lo que sea, lo vuelve a lanzar a los 5 segundos.
//   - Al parar el servicio (o apagar el PC) crea parar.flag: el puente apaga la
//     tira y termina solo. Si no lo hace en 6 segundos, se cierra a la fuerza.
//   - Apunta lo que hace en servicio.log.
//
// servicio.cfg (lo escribe instalar_servicio.bat):
//   línea 1: ruta completa de pythonw.exe
//   línea 2: opciones del puente (por ejemplo --puerto 5568)
//
// Prueba sin instalar: PuenteHyperionServicio.exe --consola

using System;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Runtime.InteropServices;
using System.ServiceProcess;
using System.Text;
using System.Threading;

// Mete el puente en un «trabajo» de Windows: si el lanzador muere de golpe,
// Windows cierra también el puente y no se quedan dos funcionando a la vez.
internal static class TrabajoWindows
{
    [StructLayout(LayoutKind.Sequential)]
    private struct LimitesBasicos
    {
        public long PerProcessUserTimeLimit;
        public long PerJobUserTimeLimit;
        public uint LimitFlags;
        public UIntPtr MinimumWorkingSetSize;
        public UIntPtr MaximumWorkingSetSize;
        public uint ActiveProcessLimit;
        public UIntPtr Affinity;
        public uint PriorityClass;
        public uint SchedulingClass;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct ContadoresES
    {
        public ulong ReadOperationCount, WriteOperationCount, OtherOperationCount;
        public ulong ReadTransferCount, WriteTransferCount, OtherTransferCount;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct LimitesAmpliados
    {
        public LimitesBasicos BasicLimitInformation;
        public ContadoresES IoInfo;
        public UIntPtr ProcessMemoryLimit;
        public UIntPtr JobMemoryLimit;
        public UIntPtr PeakProcessMemoryUsed;
        public UIntPtr PeakJobMemoryUsed;
    }

    [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    private static extern IntPtr CreateJobObject(IntPtr atributos, string nombre);

    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern bool SetInformationJobObject(IntPtr trabajo, int clase, IntPtr info, uint largo);

    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern bool AssignProcessToJobObject(IntPtr trabajo, IntPtr proceso);

    private const int JobObjectExtendedLimitInformation = 9;
    private const uint JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE = 0x2000;
    private static IntPtr trabajo = IntPtr.Zero;

    public static bool Vincular(Process p)
    {
        if (trabajo == IntPtr.Zero)
        {
            IntPtr t = CreateJobObject(IntPtr.Zero, null);
            if (t == IntPtr.Zero) return false;
            LimitesAmpliados info = new LimitesAmpliados();
            info.BasicLimitInformation.LimitFlags = JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE;
            int largo = Marshal.SizeOf(typeof(LimitesAmpliados));
            IntPtr ptr = Marshal.AllocHGlobal(largo);
            try
            {
                Marshal.StructureToPtr(info, ptr, false);
                if (!SetInformationJobObject(t, JobObjectExtendedLimitInformation, ptr, (uint)largo)) return false;
            }
            finally
            {
                Marshal.FreeHGlobal(ptr);
            }
            trabajo = t;
        }
        return AssignProcessToJobObject(trabajo, p.Handle);
    }
}

public class PuenteServicio : ServiceBase
{
    public const string Nombre = "PuenteHyperionRobobloq";

    private readonly string carpeta;
    private readonly object cerrojo = new object();
    private Process proceso;
    private Thread vigilante;
    private volatile bool parando;

    public PuenteServicio()
    {
        ServiceName = Nombre;
        CanStop = true;
        CanShutdown = true;
        AutoLog = true;
        carpeta = AppDomain.CurrentDomain.BaseDirectory;
    }

    private string Ruta(string nombre)
    {
        return Path.Combine(carpeta, nombre);
    }

    private void Anotar(string texto)
    {
        try
        {
            File.AppendAllText(Ruta("servicio.log"),
                DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + " " + texto + Environment.NewLine,
                Encoding.UTF8);
        }
        catch
        {
        }
    }

    private static Encoding CodificacionCfg()
    {
        // servicio.cfg lo escribe un .bat con «echo», que usa la página de códigos OEM.
        try
        {
            return Encoding.GetEncoding(CultureInfo.CurrentCulture.TextInfo.OEMCodePage);
        }
        catch
        {
            return Encoding.Default;
        }
    }

    protected override void OnStart(string[] args)
    {
        Arrancar();
    }

    protected override void OnStop()
    {
        Parar();
    }

    protected override void OnShutdown()
    {
        Parar();
    }

    public void Arrancar()
    {
        parando = false;
        try { File.Delete(Ruta("parar.flag")); } catch { }
        Anotar("Servicio en marcha");
        vigilante = new Thread(Bucle);
        vigilante.IsBackground = true;
        vigilante.Start();
    }

    private void Bucle()
    {
        while (!parando)
        {
            try
            {
                string[] cfg = File.ReadAllLines(Ruta("servicio.cfg"), CodificacionCfg());
                string python = cfg.Length > 0 ? cfg[0].Trim().Trim('"') : "pythonw.exe";
                string opciones = cfg.Length > 1 ? cfg[1].Trim() : "--puerto 5568";

                ProcessStartInfo psi = new ProcessStartInfo();
                psi.FileName = python;
                psi.Arguments = "\"" + Ruta("robobloq_bridge.py") + "\" " + opciones
                    + " --registro \"" + Ruta("puente.log") + "\""
                    + " --fichero-parada \"" + Ruta("parar.flag") + "\"";
                psi.WorkingDirectory = carpeta;
                psi.UseShellExecute = false;
                psi.CreateNoWindow = true;

                Process p;
                lock (cerrojo)
                {
                    if (parando) break;
                    Anotar("Arranco el puente: " + python + " " + psi.Arguments);
                    p = Process.Start(psi);
                    proceso = p;
                }
                if (!TrabajoWindows.Vincular(p))
                {
                    Anotar("Aviso: no se pudo atar el puente al servicio (error " + Marshal.GetLastWin32Error() + ")");
                }
                p.WaitForExit();
                Anotar("El puente ha terminado (código " + p.ExitCode + ")");
            }
            catch (Exception e)
            {
                Anotar("No se pudo arrancar el puente: " + e.Message);
            }
            for (int i = 0; i < 50 && !parando; i++)
            {
                Thread.Sleep(100);
            }
        }
    }

    public void Parar()
    {
        Process p;
        lock (cerrojo)
        {
            parando = true;
            p = proceso;
        }
        try
        {
            if (p != null && !p.HasExited)
            {
                File.WriteAllText(Ruta("parar.flag"), "parar");
                if (!p.WaitForExit(6000))
                {
                    p.Kill();
                    Anotar("El puente no terminó a tiempo; cerrado a la fuerza");
                }
            }
        }
        catch (Exception e)
        {
            Anotar("Error al parar el puente: " + e.Message);
        }
        try { File.Delete(Ruta("parar.flag")); } catch { }
        Anotar("Servicio parado");
    }

    public static void Main(string[] args)
    {
        if (args.Length > 0 && args[0] == "--consola")
        {
            PuenteServicio s = new PuenteServicio();
            s.Arrancar();
            Console.WriteLine("Puente en marcha en modo consola. Pulsa Intro para pararlo.");
            Console.ReadLine();
            s.Parar();
            return;
        }
        ServiceBase.Run(new PuenteServicio());
    }
}
