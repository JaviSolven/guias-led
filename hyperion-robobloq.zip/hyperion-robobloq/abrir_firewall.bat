@echo off
rem Solo hace falta si Hyperion esta en OTRO equipo de la red.
rem Ejecutar con boton derecho -> "Ejecutar como administrador".
net session >nul 2>&1
if errorlevel 1 (
  echo Hay que ejecutarlo como administrador: boton derecho, "Ejecutar como administrador".
  pause
  exit /b 1
)
netsh advfirewall firewall delete rule name="Puente Hyperion Robobloq" >nul 2>&1
netsh advfirewall firewall add rule name="Puente Hyperion Robobloq" dir=in action=allow protocol=UDP localport=5568 profile=private,domain
echo.
echo Abierto el puerto UDP 5568 de entrada (redes privadas y de dominio).
pause
