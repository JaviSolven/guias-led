@echo off
rem MODO NORMAL: 34 zonas de color, como DX Light.
rem Se aplica al momento: no hace falta reiniciar el puente ni el servicio.
cd /d "%~dp0"
> "%~dp0zonas.txt" echo 34
echo.
echo   Tira en MODO NORMAL: 34 zonas de color.
echo   El puente lo aplica en un segundo. Esta ventana se cierra sola.
ping -n 4 127.0.0.1 >nul
