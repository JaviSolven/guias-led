@echo off
rem Da la vuelta a la barra de abajo: si en Hyperion lo de abajo va al reves.
rem Se aplica al momento: no hace falta reiniciar el puente ni el servicio.
cd /d "%~dp0"
py -3 robobloq_bridge.py --invertir barra
echo.
echo   Esta ventana se cierra sola.
ping -n 6 127.0.0.1 >nul
