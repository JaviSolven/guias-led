@echo off
rem Instala el puente como SERVICIO de Windows ("Puente Hyperion Robobloq"):
rem arranca solo al encender el PC, sin ninguna ventana, y Windows lo vuelve
rem a arrancar si falla. Sustituye a arranque_automatico.bat.
rem
rem Ejecutar con boton derecho -> "Ejecutar como administrador".
rem Se puede volver a ejecutar cuando quieras (por ejemplo tras actualizar
rem robobloq_bridge.py o cambiar las opciones): reinstala el servicio.
rem
rem Opciones del puente. Si Hyperion esta en OTRO PC de la red, usa:
rem   set "OPCIONES=--puerto 5568 --escuchar 0.0.0.0"
rem Y si quieres mas zonas o mas brillo, anade --max-tramos 60 o --sin-limite.
set "OPCIONES=--puerto 5568"
set "SERVICIO=PuenteHyperionRobobloq"

cd /d "%~dp0"
net session >nul 2>&1
if errorlevel 1 (
  echo Hay que ejecutarlo como administrador: boton derecho, "Ejecutar como administrador".
  pause
  exit /b 1
)

echo.
echo === 1/5  Quitando versiones anteriores ===
sc query %SERVICIO% >nul 2>&1
if not errorlevel 1 (
  sc stop %SERVICIO% >nul 2>&1
  ping -n 9 127.0.0.1 >nul
  sc delete %SERVICIO% >nul 2>&1
  ping -n 3 127.0.0.1 >nul
)
powershell -NoProfile -ExecutionPolicy Bypass -Command "$l=[Environment]::GetFolderPath('Startup')+'\Puente Hyperion Robobloq.lnk'; if (Test-Path $l) { Remove-Item $l; '   Quitado el arranque automatico antiguo.' }; $p=Get-CimInstance Win32_Process | Where-Object { $_.Name -like 'py*' -and $_.ProcessId -ne $PID -and $_.CommandLine -like '*robobloq_bridge.py*' }; foreach ($x in $p) { Stop-Process -Id $x.ProcessId -Force -ErrorAction SilentlyContinue }; if (@($p).Count) { '   Cerradas ' + @($p).Count + ' ventanas/procesos del puente.' }"

echo === 2/5  Buscando Python ===
set "PY="
for /f "delims=" %%i in ('py -3 -c "import sys;print(sys.executable)" 2^>nul') do set "PY=%%i"
if not defined PY goto sinpython
set "PYTHONW=%PY:python.exe=pythonw.exe%"
if not exist "%PYTHONW%" goto sinpython
echo    %PYTHONW%
> "%~dp0servicio.cfg" echo %PYTHONW%
>> "%~dp0servicio.cfg" echo %OPCIONES%

echo === 3/5  Preparando el lanzador del servicio ===
set "CSC=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if not exist "%CSC%" set "CSC=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe"
if not exist "%CSC%" goto sincsc
"%CSC%" /nologo /target:exe /out:"%~dp0PuenteHyperionServicio.exe" /reference:System.ServiceProcess.dll "%~dp0servicio_windows.cs"
if errorlevel 1 goto sincsc

echo === 4/5  Registrando el servicio ===
sc create %SERVICIO% binPath= "\"%~dp0PuenteHyperionServicio.exe\"" start= auto DisplayName= "Puente Hyperion Robobloq" >nul
if errorlevel 1 goto sinservicio
set "CARPETA=%~dp0"
set "CARPETA=%CARPETA:~0,-1%"
sc description %SERVICIO% "Traduce los colores de Hyperion (udpraw, UDP 5568) a la tira LED USB Robobloq / DX Light. Carpeta: %CARPETA%" >nul
sc failure %SERVICIO% reset= 86400 actions= restart/5000/restart/5000/restart/30000 >nul

echo === 5/5  Arrancando ===
sc start %SERVICIO% >nul
ping -n 6 127.0.0.1 >nul
sc query %SERVICIO% | "%SystemRoot%\System32\find.exe" "RUNNING" >nul
if errorlevel 1 goto noarranca

echo.
echo LISTO. El servicio "Puente Hyperion Robobloq" esta funcionando y arrancara
echo solo cada vez que enciendas el PC, sin ventanas.
echo Lo ves en: Windows+R, escribe services.msc, busca "Puente Hyperion Robobloq".
echo Ultimas lineas de puente.log:
powershell -NoProfile -Command "if (Test-Path '%~dp0puente.log') { Get-Content '%~dp0puente.log' -Tail 6 -Encoding UTF8 }"
echo.
pause
exit /b 0

:sinpython
echo No encuentro Python (pythonw.exe). Instala Python desde python.org (fase 3 de la guia).
pause
exit /b 1

:sincsc
echo No se pudo preparar el lanzador del servicio (falta .NET Framework 4 o fallo al compilar).
echo Usa arranque_automatico.bat en su lugar.
pause
exit /b 1

:sinservicio
echo No se pudo registrar el servicio. Ejecuta desinstalar_servicio.bat y vuelve a probar.
pause
exit /b 1

:noarranca
echo El servicio esta instalado pero no ha arrancado. Mira servicio.log y puente.log
echo en %~dp0 y pasaselos a Claude.
pause
exit /b 1
