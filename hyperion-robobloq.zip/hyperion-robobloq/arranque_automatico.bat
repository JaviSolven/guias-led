@echo off
rem Hace que el puente arranque solo, sin ventana, al iniciar sesion en Windows,
rem y lo arranca ya. No necesita permisos de administrador.
rem Si Hyperion esta en OTRO PC de la red, cambia ARGS por:
rem   set "ARGS=--puerto 5568 --escuchar 0.0.0.0"
set "ARGS=--puerto 5568"

cd /d "%~dp0"
set "PYW="
for /f "delims=" %%i in ('where pyw 2^>nul') do if not defined PYW set "PYW=%%i"
if not defined PYW (
  echo No encuentro pyw.exe. Instala Python desde python.org dejando marcado "py launcher".
  pause
  exit /b 1
)

powershell -NoProfile -ExecutionPolicy Bypass -Command "$s=(New-Object -ComObject WScript.Shell).CreateShortcut([Environment]::GetFolderPath('Startup')+'\Puente Hyperion Robobloq.lnk'); $s.TargetPath='%PYW%'; $s.Arguments='-3 \"%~dp0robobloq_bridge.py\" %ARGS% --registro \"%~dp0puente.log\"'; $s.WorkingDirectory='%~dp0'; $s.Save()"
if errorlevel 1 (
  echo No se pudo crear el acceso directo de inicio.
  pause
  exit /b 1
)

start "" "%PYW%" -3 "%~dp0robobloq_bridge.py" %ARGS% --registro "%~dp0puente.log"
echo.
echo Listo. El puente ya esta funcionando y arrancara solo al iniciar sesion.
echo Sus mensajes quedan en: %~dp0puente.log
echo Para quitarlo: quitar_arranque.bat
pause
