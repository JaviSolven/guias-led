@echo off
rem Pinta la tira en bloques de 10 LEDs de colores para contar cuantos hay en cada lado.
rem ANTES: cierra DX Light y el puente (si esta abierto).
cd /d "%~dp0"
py -3 robobloq_bridge.py --contar --segundos 180
echo.
pause
