@echo off
rem Comprueba que se ve la tira y hace la secuencia de colores de prueba.
rem ANTES: cierra DX Light (tambien el icono junto al reloj).
cd /d "%~dp0"
echo.
echo === Buscando la tira ===
py -3 robobloq_bridge.py --listar
if errorlevel 1 goto fin
echo.
echo === Datos de la tira ===
py -3 robobloq_bridge.py --info
echo.
echo Ahora va la prueba de colores: rojo, verde, azul, blanco
echo y luego un punto rojo que recorre la tira desde el LED 1.
echo FIJATE en donde empieza el punto y hacia donde va.
pause
py -3 robobloq_bridge.py --prueba
:fin
echo.
pause
