@echo off
rem Para el puente y quita el arranque automatico.
powershell -NoProfile -ExecutionPolicy Bypass -Command "$l=[Environment]::GetFolderPath('Startup')+'\Puente Hyperion Robobloq.lnk'; if (Test-Path $l) { Remove-Item $l; 'Arranque automatico quitado.' } else { 'No estaba en el arranque automatico.' }; $p=Get-CimInstance Win32_Process | Where-Object { $_.Name -like 'py*' -and $_.ProcessId -ne $PID -and $_.CommandLine -like '*robobloq_bridge.py*' }; foreach ($x in $p) { Stop-Process -Id $x.ProcessId -Force -ErrorAction SilentlyContinue }; 'Procesos del puente parados: ' + @($p).Count"
echo La tira puede quedarse con el ultimo color que tenia.
pause
