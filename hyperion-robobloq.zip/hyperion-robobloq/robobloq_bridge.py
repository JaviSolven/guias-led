#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Puente Hyperion -> tira LED Robobloq («DX Light» / «QuikLight») por USB.

Hyperion (controlador LED «udpraw») manda por UDP los colores de cada LED
(R,G,B,R,G,B,...). Este programa los recibe y los traduce al protocolo propio
del controlador USB de la tira, el mismo que usa el programa oficial
DX Light 3.11.0 (sacado de su código y contrastado con el driver de OpenRGB).

Dispositivos admitidos
  VID 0x1A86  PID 0xFE07  -> HID (lo normal)
  VID 0x1A86  PID 0xFE0C  -> puerto serie USB (CDC), 115200 8N1

Protocolo
  Trama corta "RB": 'R' 'B' | largo(1) | sec(1) | orden(1) | datos... | suma(1)
  Trama larga "SC": 'S' 'C' | largo(2, big-endian) | sec(1) | 0x80 | tramos... | suma(1)
    suma  = suma de todos los bytes anteriores, módulo 256
    largo = bytes totales de la trama, suma incluida
    tramo = [led_inicio, R, G, B, led_fin]   (índices desde 1)
  Por HID la trama se trocea en informes de 64 bytes, cada uno precedido de 0x00.
  Firmware <= 1.0.2: no entiende "SC"; se usa la orden 0x86 en tramas "RB"
  de 11 tramos como máximo.

Sin dependencias en Windows ni en Linux:
  - Windows: usa la API HID del propio sistema (hid.dll) con ctypes
  - Linux: escribe directamente en /dev/hidrawX
  - Si está instalado «hidapi» (pip install hidapi) se usa ese primero
  - pip install pyserial   solo si la tira aparece como puerto serie (PID FE0C)

Varias tiras a la vez (desde la versión 1.3.0)
  Si junto al puente hay un fichero tiras.txt (lo crea --configurar), el puente
  abre todas las tiras que lista, cada una reconocida por su número de serie
  (uuid), y reparte entre ellas los colores que manda Hyperion. Cada tira puede
  tener tramos de LEDs encendidos, copiados o apagados. Sin tiras.txt funciona
  como siempre, con una sola tira.
"""

import argparse
import glob
import logging
import os
import socket
import sys
import threading
import time

__version__ = "1.3.0"

VID = 0x1A86
PID_HID = 0xFE07
PID_SERIE = 0xFE0C

ORDEN_SINCRO = 0x80     # colores por tramos, trama larga "SC"
ORDEN_INFO = 0x82       # leer información del dispositivo
ORDEN_TRAMOS = 0x86     # colores por tramos, trama corta "RB" (firmware antiguo)
ORDEN_BRILLO = 0x87
ORDEN_URL = 0x93        # 0 = que no abra la web del fabricante al conectar
ORDEN_APAGAR = 0x97
AVISO_ESTADO = 0xF1     # lo manda la tira al pulsar su botón de sincronía

MAX_LEDS = 254          # los índices de LED van en un byte
TRAMOS_POR_TRAMA_RB = 11

log = logging.getLogger("robobloq")


# --------------------------------------------------------------------------
# Construcción de tramas
# --------------------------------------------------------------------------

class Secuencia:
    """Número de secuencia 2..254, igual que el programa oficial."""

    def __init__(self):
        self.n = 1

    def siguiente(self):
        self.n += 1
        if self.n >= 255:
            self.n = 1
        return self.n


def suma_control(datos):
    return sum(datos) & 0xFF


def trama_rb(sec, orden, datos=()):
    largo = len(datos) + 6
    if largo > 64:
        raise ValueError("trama RB demasiado larga: %d bytes" % largo)
    t = bytearray(b"RB")
    t += bytes((largo, sec, orden))
    t += bytes(datos)
    t.append(suma_control(t))
    return bytes(t)


def trama_sc(sec, tramos_planos):
    largo = len(tramos_planos) + 7
    if largo > 0xFFFF:
        raise ValueError("trama SC demasiado larga")
    t = bytearray(b"SC")
    t += largo.to_bytes(2, "big")
    t += bytes((sec, ORDEN_SINCRO))
    t += bytes(tramos_planos)
    t.append(suma_control(t))
    return bytes(t)


def interpretar_info(r):
    """Respuesta a ORDEN_INFO (HID/serie de tira). None si no cuadra."""
    if not r or len(r) < 24 or r[0:2] != b"RB":
        return None
    return {
        "id": r[5:8].hex(),
        "pulgadas": r[8],
        "leds": r[11],
        "uuid": r[12:20].hex(),
        "version": (r[21], r[22], r[23]),
    }


# --------------------------------------------------------------------------
# De colores de Hyperion a tramos de la tira
# --------------------------------------------------------------------------

def limitar_potencia(r, g, b):
    """Como DX Light: si R+G+B > 255 se escala para no pasar del consumo
    que aguanta el USB. Un blanco puro queda en (85, 85, 85)."""
    s = r + g + b
    if s > 255:
        f = s / 255.0
        return int(r / f), int(g / f), int(b / f)
    return r, g, b


def _largo(t):
    return t[1] - t[0] + 1


def _unir(a, b):
    la, lb = _largo(a), _largo(b)
    total = la + lb
    return [a[0], b[1],
            (a[2] * la + b[2] * lb + total // 2) // total,
            (a[3] * la + b[3] * lb + total // 2) // total,
            (a[4] * la + b[4] * lb + total // 2) // total]


def _coste(a, b):
    dif = abs(a[2] - b[2]) + abs(a[3] - b[3]) + abs(a[4] - b[4])
    return (dif + 1) * (_largo(a) + _largo(b))


def construir_tramos(colores, n_leds, max_tramos=34, limitar=True):
    """colores: lista de (r, g, b) tal como llegan de Hyperion.
    Devuelve la lista plana [ini, r, g, b, fin, ini, r, g, b, fin, ...]."""
    n_leds = max(1, min(int(n_leds), MAX_LEDS))
    max_tramos = max(1, int(max_tramos))
    if not colores:
        return []

    # Más colores que LEDs físicos: se promedian.
    n = len(colores)
    if n > n_leds:
        nuevos = []
        for j in range(n_leds):
            a = j * n // n_leds
            b = max(a + 1, (j + 1) * n // n_leds)
            grupo = colores[a:b]
            k = len(grupo)
            nuevos.append((sum(c[0] for c in grupo) // k,
                           sum(c[1] for c in grupo) // k,
                           sum(c[2] for c in grupo) // k))
        colores = nuevos
        n = n_leds

    # Cada color de Hyperion ocupa un tramo de LEDs consecutivos; si hay
    # menos colores que LEDs, el sobrante se reparte entre los primeros
    # (mismo reparto que DX Light).
    base, resto = divmod(n_leds, n)
    tramos = []
    ini = 1
    for i, c in enumerate(colores):
        largo = base + (1 if i < resto else 0)
        tramos.append([ini, ini + largo - 1, int(c[0]), int(c[1]), int(c[2])])
        ini += largo

    # Vecinos del mismo color: se juntan sin perder nada.
    i = 0
    while i < len(tramos) - 1:
        if tramos[i][2:] == tramos[i + 1][2:]:
            tramos[i][1] = tramos[i + 1][1]
            del tramos[i + 1]
        else:
            i += 1

    # Si siguen siendo demasiados, se juntan los vecinos más parecidos
    # (y más cortos) hasta caber en max_tramos.
    if len(tramos) > max_tramos:
        costes = [_coste(tramos[k], tramos[k + 1]) for k in range(len(tramos) - 1)]
        while len(tramos) > max_tramos:
            k = costes.index(min(costes))
            tramos[k] = _unir(tramos[k], tramos[k + 1])
            del tramos[k + 1]
            del costes[k]
            if k > 0:
                costes[k - 1] = _coste(tramos[k - 1], tramos[k])
            if k < len(tramos) - 1:
                costes[k] = _coste(tramos[k], tramos[k + 1])

    plano = []
    for ini, fin, r, g, b in tramos:
        if limitar:
            r, g, b = limitar_potencia(r, g, b)
        plano += [ini, r, g, b, fin]
    return plano


def tramos_color_unico(n_leds, r, g, b, limitar=True):
    return construir_tramos([(r, g, b)], n_leds, 1, limitar)


# --------------------------------------------------------------------------
# Transportes
# --------------------------------------------------------------------------

def _trocear_hid(trama):
    for i in range(0, len(trama), 64):
        yield b"\x00" + trama[i:i + 64].ljust(64, b"\x00")


class TransporteHidapi:
    """Paquete «hidapi» (import hid, clase hid.device) o «hid» (hid.Device)."""
    nombre = "HID (hidapi)"

    def __init__(self, ruta):
        import hid
        if hasattr(hid, "device"):
            self.dev = hid.device()
            self.dev.open_path(ruta)
            self._leer = lambda ms: bytes(self.dev.read(64, ms) or b"")
        else:
            self.dev = hid.Device(path=ruta)
            self._leer = lambda ms: bytes(self.dev.read(64, ms) or b"")
        self.ruta = ruta

    def escribir(self, trama):
        for informe in _trocear_hid(trama):
            n = self.dev.write(informe)
            if n is not None and n < 0:
                raise IOError("fallo al escribir en el HID")

    def leer(self, ms):
        return self._leer(ms)

    def cerrar(self):
        try:
            self.dev.close()
        except Exception:
            pass

    @staticmethod
    def buscar():
        try:
            import hid
        except ImportError:
            return []
        try:
            lista = hid.enumerate(VID, PID_HID)
        except Exception:
            return []

        def prioridad(d):
            if d.get("usage_page") == 0xFF00:
                return 0
            if d.get("interface_number") == 0:
                return 1
            return 2

        vistas, rutas = set(), []
        for d in sorted(lista, key=prioridad):
            p = d.get("path")
            if p and p not in vistas:
                vistas.add(p)
                rutas.append(p)
        return rutas


class TransporteHidraw:
    """Linux sin librerías: escribe directamente en /dev/hidrawX."""
    nombre = "HID (hidraw)"

    def __init__(self, ruta):
        self.fd = os.open(ruta, os.O_RDWR | os.O_NONBLOCK)
        self.ruta = ruta

    def escribir(self, trama):
        for informe in _trocear_hid(trama):
            os.write(self.fd, informe)

    def leer(self, ms):
        import select
        listos, _, _ = select.select([self.fd], [], [], ms / 1000.0)
        if not listos:
            return b""
        try:
            return os.read(self.fd, 64)
        except (BlockingIOError, InterruptedError):
            return b""

    def cerrar(self):
        try:
            os.close(self.fd)
        except OSError:
            pass

    @staticmethod
    def buscar():
        if not sys.platform.startswith("linux"):
            return []
        encontrados = []
        buscado = "HID_ID=0003:%08X:%08X" % (VID, PID_HID)
        for d in sorted(glob.glob("/sys/class/hidraw/hidraw*")):
            try:
                with open(os.path.join(d, "device", "uevent")) as f:
                    uevent = f.read().upper()
            except OSError:
                continue
            if buscado not in uevent:
                continue
            try:
                with open(os.path.join(d, "device", "report_descriptor"), "rb") as f:
                    desc = f.read()
            except OSError:
                desc = b""
            # Prioridad a la interfaz de fabricante (usage page 0xFF00)
            prio = 0 if desc[:3] == b"\x06\x00\xff" else 1
            encontrados.append((prio, "/dev/" + os.path.basename(d)))
        return [r for _, r in sorted(encontrados)]


_WIN = None


def _win_api():
    """Carga (una sola vez) las funciones HID de Windows con ctypes."""
    global _WIN
    if _WIN is not None:
        return _WIN
    import ctypes
    from ctypes import wintypes as w

    class GUID(ctypes.Structure):
        _fields_ = [("Data1", w.DWORD), ("Data2", w.WORD), ("Data3", w.WORD),
                    ("Data4", ctypes.c_ubyte * 8)]

    class IFACE(ctypes.Structure):  # SP_DEVICE_INTERFACE_DATA
        _fields_ = [("cbSize", w.DWORD), ("InterfaceClassGuid", GUID),
                    ("Flags", w.DWORD), ("Reserved", ctypes.c_size_t)]

    class ATTR(ctypes.Structure):  # HIDD_ATTRIBUTES
        _fields_ = [("Size", w.ULONG), ("VendorID", w.USHORT),
                    ("ProductID", w.USHORT), ("VersionNumber", w.USHORT)]

    class CAPS(ctypes.Structure):  # HIDP_CAPS
        _fields_ = [("Usage", w.USHORT), ("UsagePage", w.USHORT),
                    ("InputReportByteLength", w.USHORT),
                    ("OutputReportByteLength", w.USHORT),
                    ("FeatureReportByteLength", w.USHORT),
                    ("Reserved", w.USHORT * 17), ("Resto", w.USHORT * 10)]

    class OVERLAPPED(ctypes.Structure):
        _fields_ = [("Internal", ctypes.c_size_t), ("InternalHigh", ctypes.c_size_t),
                    ("Offset", w.DWORD), ("OffsetHigh", w.DWORD), ("hEvent", w.HANDLE)]

    k32 = ctypes.WinDLL("kernel32", use_last_error=True)
    sapi = ctypes.WinDLL("setupapi", use_last_error=True)
    hid = ctypes.WinDLL("hid")
    P = ctypes.POINTER

    def firma(f, res, *args):
        f.restype = res
        f.argtypes = list(args)
        return f

    api = {
        "ctypes": ctypes, "GUID": GUID, "IFACE": IFACE, "ATTR": ATTR, "CAPS": CAPS,
        "OVERLAPPED": OVERLAPPED,
        "INVALIDO": ctypes.c_void_p(-1).value,
        "CreateFileW": firma(k32.CreateFileW, w.HANDLE, w.LPCWSTR, w.DWORD, w.DWORD,
                             ctypes.c_void_p, w.DWORD, w.DWORD, w.HANDLE),
        "CloseHandle": firma(k32.CloseHandle, w.BOOL, w.HANDLE),
        "CreateEventW": firma(k32.CreateEventW, w.HANDLE, ctypes.c_void_p, w.BOOL,
                              w.BOOL, w.LPCWSTR),
        "ResetEvent": firma(k32.ResetEvent, w.BOOL, w.HANDLE),
        "ReadFile": firma(k32.ReadFile, w.BOOL, w.HANDLE, ctypes.c_void_p, w.DWORD,
                          P(w.DWORD), P(OVERLAPPED)),
        "WriteFile": firma(k32.WriteFile, w.BOOL, w.HANDLE, ctypes.c_void_p, w.DWORD,
                           P(w.DWORD), P(OVERLAPPED)),
        "GetOverlappedResult": firma(k32.GetOverlappedResult, w.BOOL, w.HANDLE,
                                     P(OVERLAPPED), P(w.DWORD), w.BOOL),
        "WaitForSingleObject": firma(k32.WaitForSingleObject, w.DWORD, w.HANDLE, w.DWORD),
        "CancelIo": firma(k32.CancelIo, w.BOOL, w.HANDLE),
        "SetupDiGetClassDevsW": firma(sapi.SetupDiGetClassDevsW, ctypes.c_void_p,
                                      P(GUID), w.LPCWSTR, w.HWND, w.DWORD),
        "SetupDiEnumDeviceInterfaces": firma(sapi.SetupDiEnumDeviceInterfaces, w.BOOL,
                                             ctypes.c_void_p, ctypes.c_void_p, P(GUID),
                                             w.DWORD, P(IFACE)),
        "SetupDiGetDeviceInterfaceDetailW": firma(sapi.SetupDiGetDeviceInterfaceDetailW,
                                                  w.BOOL, ctypes.c_void_p, P(IFACE),
                                                  ctypes.c_void_p, w.DWORD, P(w.DWORD),
                                                  ctypes.c_void_p),
        "SetupDiDestroyDeviceInfoList": firma(sapi.SetupDiDestroyDeviceInfoList, w.BOOL,
                                              ctypes.c_void_p),
        "HidD_GetHidGuid": firma(hid.HidD_GetHidGuid, None, P(GUID)),
        "HidD_GetAttributes": firma(hid.HidD_GetAttributes, ctypes.c_ubyte, w.HANDLE, P(ATTR)),
        "HidD_GetPreparsedData": firma(hid.HidD_GetPreparsedData, ctypes.c_ubyte, w.HANDLE,
                                       P(ctypes.c_void_p)),
        "HidD_FreePreparsedData": firma(hid.HidD_FreePreparsedData, ctypes.c_ubyte,
                                        ctypes.c_void_p),
        "HidP_GetCaps": firma(hid.HidP_GetCaps, ctypes.c_long, ctypes.c_void_p, P(CAPS)),
    }
    _WIN = api
    return api


def _win_abrir(ruta, acceso):
    a = _win_api()
    # FILE_SHARE_READ|WRITE, OPEN_EXISTING, FILE_FLAG_OVERLAPPED
    h = a["CreateFileW"](ruta, acceso, 3, None, 3, 0x40000000, None)
    if h in (None, 0, a["INVALIDO"]):
        raise OSError(a["ctypes"].get_last_error(), "no se pudo abrir el HID")
    return h


def _win_caps(h):
    a = _win_api()
    ct = a["ctypes"]
    pp = ct.c_void_p()
    if not a["HidD_GetPreparsedData"](h, ct.byref(pp)):
        return None
    caps = a["CAPS"]()
    try:
        if a["HidP_GetCaps"](pp, ct.byref(caps)) != 0x00110000:
            return None
    finally:
        a["HidD_FreePreparsedData"](pp)
    return caps


def _win_listar(filtro):
    """Interfaces HID presentes cuya ruta contiene `filtro` (p. ej. 'vid_1a86&pid_fe07')."""
    a = _win_api()
    ct = a["ctypes"]
    guid = a["GUID"]()
    a["HidD_GetHidGuid"](ct.byref(guid))
    lista = a["SetupDiGetClassDevsW"](ct.byref(guid), None, None, 0x02 | 0x10)
    if lista in (None, a["INVALIDO"]):
        return []
    res = []
    try:
        i = 0
        while True:
            d = a["IFACE"]()
            d.cbSize = ct.sizeof(d)
            if not a["SetupDiEnumDeviceInterfaces"](lista, None, ct.byref(guid), i, ct.byref(d)):
                break
            i += 1
            n = ct.c_ulong(0)
            a["SetupDiGetDeviceInterfaceDetailW"](lista, ct.byref(d), None, 0, ct.byref(n), None)
            if n.value < 8:
                continue
            buf = ct.create_string_buffer(n.value)
            # cbSize de SP_DEVICE_INTERFACE_DETAIL_DATA_W: 8 en 64 bits, 6 en 32
            ct.c_ulong.from_buffer(buf).value = 8 if ct.sizeof(ct.c_void_p) == 8 else 6
            if not a["SetupDiGetDeviceInterfaceDetailW"](lista, ct.byref(d), buf, n, None, None):
                continue
            ruta = ct.wstring_at(ct.addressof(buf) + 4)
            if filtro and filtro not in ruta.lower():
                continue
            info = {"ruta": ruta, "usage_page": None, "usage": None, "entrada": 0, "salida": 0}
            try:
                h = _win_abrir(ruta, 0)  # sin acceso: basta para leer las capacidades
            except OSError:
                res.append(info)
                continue
            try:
                caps = _win_caps(h)
                if caps is not None:
                    info.update(usage_page=caps.UsagePage, usage=caps.Usage,
                                entrada=caps.InputReportByteLength,
                                salida=caps.OutputReportByteLength)
            finally:
                a["CloseHandle"](h)
            res.append(info)
    finally:
        a["SetupDiDestroyDeviceInfoList"](lista)
    return res


class TransporteHidWindows:
    """Windows sin instalar nada: API HID del propio Windows (hid.dll)."""
    nombre = "HID (Windows)"

    def __init__(self, ruta):
        a = self.a = _win_api()
        ct = a["ctypes"]
        self.ruta = ruta
        self.h = _win_abrir(ruta, 0x80000000 | 0x40000000)  # GENERIC_READ|WRITE
        caps = _win_caps(self.h)
        if caps is None or caps.OutputReportByteLength < 65:
            a["CloseHandle"](self.h)
            raise OSError("esta interfaz HID no admite informes de 64 bytes")
        self.largo_salida = caps.OutputReportByteLength
        self.largo_entrada = max(caps.InputReportByteLength, 65)
        self.ev_w = a["CreateEventW"](None, True, False, None)
        self.ev_r = a["CreateEventW"](None, True, False, None)
        self.buf_r = ct.create_string_buffer(self.largo_entrada)
        self.ov_r = None
        self.leyendo = False

    def _esperar(self, ov, ev, ms):
        a = self.a
        ct = a["ctypes"]
        if a["WaitForSingleObject"](ev, ms) != 0:
            return None
        n = ct.c_ulong(0)
        if not a["GetOverlappedResult"](self.h, ct.byref(ov), ct.byref(n), False):
            raise OSError(ct.get_last_error(), "fallo de E/S en el HID")
        return n.value

    def escribir(self, trama):
        a = self.a
        ct = a["ctypes"]
        for informe in _trocear_hid(trama):
            datos = informe.ljust(self.largo_salida, b"\x00")
            buf = ct.create_string_buffer(datos, len(datos))
            a["ResetEvent"](self.ev_w)
            ov = a["OVERLAPPED"](hEvent=self.ev_w)
            if not a["WriteFile"](self.h, buf, len(datos), None, ct.byref(ov)):
                err = ct.get_last_error()
                if err != 997:  # ERROR_IO_PENDING
                    raise OSError(err, "no se pudo escribir en el HID")
            if self._esperar(ov, self.ev_w, 1000) is None:
                a["CancelIo"](self.h)
                a["GetOverlappedResult"](self.h, ct.byref(ov), ct.byref(ct.c_ulong()), True)
                self.leyendo = False  # CancelIo también cancela la lectura pendiente
                raise OSError("la tira no acepta datos (tiempo agotado)")

    def leer(self, ms):
        a = self.a
        ct = a["ctypes"]
        if not self.leyendo:
            a["ResetEvent"](self.ev_r)
            self.ov_r = a["OVERLAPPED"](hEvent=self.ev_r)
            if not a["ReadFile"](self.h, self.buf_r, self.largo_entrada, None,
                                 ct.byref(self.ov_r)):
                err = ct.get_last_error()
                if err != 997:
                    raise OSError(err, "no se pudo leer del HID")
            self.leyendo = True
        n = self._esperar(self.ov_r, self.ev_r, int(ms))
        if n is None:
            return b""  # la lectura queda pendiente para la próxima vez
        self.leyendo = False
        datos = self.buf_r.raw[:n]
        return datos[1:] if datos[:1] == b"\x00" else datos

    def cerrar(self):
        a = self.a
        ct = a["ctypes"]
        try:
            if self.leyendo:
                a["CancelIo"](self.h)
                a["GetOverlappedResult"](self.h, ct.byref(self.ov_r), ct.byref(ct.c_ulong()), True)
                self.leyendo = False
        finally:
            for h in (self.h, self.ev_w, self.ev_r):
                if h:
                    a["CloseHandle"](h)
            self.h = self.ev_w = self.ev_r = None

    @staticmethod
    def buscar():
        if sys.platform != "win32":
            return []
        try:
            lista = _win_listar("vid_%04x&pid_%04x" % (VID, PID_HID))
        except Exception as e:
            log.debug("HID de Windows: %s", e)
            return []
        validas = [d for d in lista if d["salida"] >= 65]
        validas.sort(key=lambda d: 0 if d["usage_page"] == 0xFF00 else 1)
        return [d["ruta"] for d in validas]


class TransporteSerie:
    nombre = "serie"

    def __init__(self, ruta):
        import serial
        self.p = serial.Serial(ruta, 115200, bytesize=8, timeout=0)
        self.ruta = ruta

    def escribir(self, trama):
        self.p.write(trama)

    def leer(self, ms):
        fin = time.monotonic() + ms / 1000.0
        buf = b""
        while time.monotonic() < fin:
            b = self.p.read(256)
            if b:
                buf += b
            elif buf:
                break
            else:
                time.sleep(0.005)
        return buf

    def cerrar(self):
        try:
            self.p.close()
        except Exception:
            pass

    @staticmethod
    def buscar():
        try:
            from serial.tools import list_ports
        except ImportError:
            return []
        return [p.device for p in list_ports.comports()
                if p.vid == VID and p.pid == PID_SERIE]


class TransporteSimulado:
    """No toca hardware: escribe las tramas en hexadecimal y contesta a la
    petición de información como una tira de verdad (con su propio uuid)."""
    nombre = "simulado"

    def __init__(self, ruta="sim1", leds=54):
        self.ruta = ruta
        self.leds = max(1, min(int(leds), MAX_LEDS))
        n = int("".join(ch for ch in ruta if ch.isdigit()) or "1")
        self.uuid = bytes.fromhex("51%014x" % n)
        self.respuestas = []

    def escribir(self, trama):
        log.info("-> [%s] %s", self.ruta, trama.hex(" "))
        if trama[:2] == b"RB" and len(trama) > 4 and trama[4] == ORDEN_INFO:
            r = bytearray(b"RB")
            r += bytes((25, trama[3], ORDEN_INFO))
            r += b"\x00\x06\x03"                 # id
            r += bytes((24, 0, 0, self.leds))    # pulgadas, relleno, nº de LEDs
            r += self.uuid
            r += bytes((0, 1, 7, 3))             # relleno y versión 1.7.3
            r.append(suma_control(r))
            self.respuestas.append(bytes(r))

    def leer(self, ms):
        return self.respuestas.pop(0) if self.respuestas else b""

    def cerrar(self):
        pass


class _FabricaSimulada:
    """Para --simular N: crea tiras simuladas «sim1», «sim2»..."""
    nombre = "simulado"

    def __init__(self, leds):
        self.leds = leds

    def __call__(self, ruta):
        return TransporteSimulado(ruta, self.leds)


def buscar_dispositivos():
    res = []
    for clase in (TransporteHidapi, TransporteHidWindows, TransporteHidraw, TransporteSerie):
        for ruta in clase.buscar():
            res.append((clase, ruta))
    return res


def explicar_sin_tira():
    print("- Comprueba que está enchufada y que DX Light está cerrado.")
    faltan = dependencias_que_faltan()
    if any(f.startswith("pyserial") for f in faltan):
        print("- Si en el Administrador de dispositivos sale como puerto COM con PID_FE0C,\n"
              "  instala el soporte serie:  py -3 -m pip install pyserial")
    if "hidapi" in faltan:
        print("- Instala el soporte HID:  pip install hidapi")


def dependencias_que_faltan():
    faltan = []
    try:
        import hid  # noqa: F401
    except ImportError:
        if sys.platform not in ("win32",) and not sys.platform.startswith("linux"):
            faltan.append("hidapi")
    try:
        import serial  # noqa: F401
    except ImportError:
        faltan.append("pyserial (solo para la variante serie)")
    return faltan


# --------------------------------------------------------------------------
# La tira
# --------------------------------------------------------------------------

class Tira:
    def __init__(self, transporte, leds=None, firmware_antiguo=None):
        self.t = transporte
        self.sec = Secuencia()
        self.info = None
        self.leds = leds
        self.firmware_antiguo = firmware_antiguo
        self.clave = None   # (transporte, ruta), para no abrir dos veces el mismo dispositivo

    @property
    def uuid(self):
        return self.info["uuid"] if self.info else None

    def preguntar(self, orden, datos=(), intentos=3):
        for _ in range(intentos):
            s = self.sec.siguiente()
            self.t.escribir(trama_rb(s, orden, datos))
            fin = time.monotonic() + 1.0
            while time.monotonic() < fin:
                r = self.t.leer(100)
                if not r:
                    continue
                i = r.find(b"RB")
                if i < 0:
                    continue
                r = r[i:]
                if len(r) > 4 and r[3] == s:
                    return r
                self._aviso(r)
        return None

    def _aviso(self, r):
        if len(r) > 6 and r[4] == AVISO_ESTADO:
            log.info("La tira avisa: sincronía %s (botón del mando)",
                     "ACTIVADA" if r[6] else "DESACTIVADA")

    def iniciar(self):
        self.info = interpretar_info(self.preguntar(ORDEN_INFO))
        if self.info:
            v = self.info["version"]
            log.info("Tira: id %s, %d LEDs, %d\", firmware %d.%d.%d, uuid %s",
                     self.info["id"], self.info["leds"], self.info["pulgadas"],
                     v[0], v[1], v[2], self.info["uuid"])
            if self.leds is None and self.info["leds"] > 0:
                self.leds = self.info["leds"]
            if self.firmware_antiguo is None:
                self.firmware_antiguo = v <= (1, 0, 2)
        else:
            log.warning("La tira no responde a la petición de información.")
        if self.leds is None:
            raise RuntimeError("No sé cuántos LEDs tiene la tira: indica --leds N")
        if self.firmware_antiguo is None:
            self.firmware_antiguo = False
        # Lo mismo que hace DX Light al conectar: que no abra la web.
        self.t.escribir(trama_rb(self.sec.siguiente(), ORDEN_URL, (0,)))
        time.sleep(0.05)
        log.info("Usando %d LEDs, modo %s", self.leds,
                 "antiguo (0x86)" if self.firmware_antiguo else "sincronía (SC)")

    def brillo(self, valor):
        self.t.escribir(trama_rb(self.sec.siguiente(), ORDEN_BRILLO,
                                 (max(1, min(255, int(valor))),)))

    def enviar(self, plano):
        if not plano:
            return
        if self.firmware_antiguo:
            paso = TRAMOS_POR_TRAMA_RB * 5
            for i in range(0, len(plano), paso):
                self.t.escribir(trama_rb(self.sec.siguiente(), ORDEN_TRAMOS,
                                         plano[i:i + paso]))
                time.sleep(0.02)
        else:
            self.t.escribir(trama_sc(self.sec.siguiente(), plano))

    def vaciar_entrada(self):
        for _ in range(8):
            r = self.t.leer(0)
            if not r:
                break
            i = r.find(b"RB")
            if i >= 0:
                self._aviso(r[i:])

    def negro(self):
        self.enviar(tramos_color_unico(self.leds, 0, 0, 0))


def ruta_texto(ruta):
    return ruta.decode(errors="replace") if isinstance(ruta, bytes) else str(ruta)


def candidatos(args):
    """Lista de (transporte, ruta) donde puede haber una tira."""
    if args.simular:
        fabrica = _FabricaSimulada(args.leds or 54)
        return [(fabrica, "sim%d" % (i + 1)) for i in range(args.simular)]
    if args.dispositivo:
        if args.dispositivo.startswith("/dev/hidraw"):
            return [(TransporteHidraw, args.dispositivo)]
        if args.dispositivo.startswith("\\\\?\\"):
            return [(TransporteHidWindows, args.dispositivo)]
        if args.dispositivo.upper().startswith("COM") or args.dispositivo.startswith("/dev/tty"):
            return [(TransporteSerie, args.dispositivo)]
        return [(TransporteHidapi, args.dispositivo.encode())]
    return buscar_dispositivos()


def abrir_tira(args, uuid=None):
    """Abre la primera tira que funcione (o la del uuid indicado, si se da)."""
    ultimo_error = None
    for clase, ruta in candidatos(args):
        try:
            t = clase(ruta)
        except Exception as e:  # permisos, ocupado por otro programa...
            ultimo_error = e
            log.debug("No se pudo abrir %s %s: %s", clase.nombre, ruta, e)
            continue
        log.info("Conectado por %s: %s", clase.nombre, ruta_texto(ruta))
        tira = Tira(t, leds=args.leds, firmware_antiguo=args.firmware_antiguo or None)
        tira.clave = (clase.nombre, ruta_texto(ruta))
        try:
            tira.iniciar()
        except Exception as e:
            ultimo_error = e
            t.cerrar()
            continue
        if uuid and not (tira.uuid or "").startswith(uuid.lower()):
            t.cerrar()
            continue
        return tira
    if ultimo_error and not uuid:
        raise RuntimeError("Tira encontrada pero no se pudo usar: %s" % ultimo_error)
    return None


def abrir_varias(args, quiero=None, claves_en_uso=(), uuids_en_uso=()):
    """Abre todas las tiras que encuentre, cada una una sola vez.
    quiero: uuids buscados (None = todas). Devuelve ({uuid: Tira}, claves de
    dispositivos que no interesan, para no volver a preguntarles enseguida)."""
    res = {}
    descartadas = set()
    for clase, ruta in candidatos(args):
        clave = (clase.nombre, ruta_texto(ruta))
        if clave in claves_en_uso:
            continue
        try:
            t = clase(ruta)
        except Exception as e:
            log.debug("No se pudo abrir %s %s: %s", clase.nombre, ruta_texto(ruta), e)
            continue
        tira = Tira(t, firmware_antiguo=args.firmware_antiguo or None)
        tira.clave = clave
        try:
            tira.iniciar()
        except Exception as e:
            log.debug("La tira de %s no responde: %s", ruta_texto(ruta), e)
            t.cerrar()
            continue
        u = tira.uuid
        if not u or u in res or u in uuids_en_uso or (quiero is not None and u not in quiero):
            # sin número de serie, repetida (otra forma de abrir la misma) o que no es de las buscadas
            t.cerrar()
            descartadas.add(clave)
            continue
        res[u] = tira
    return res, descartadas


# --------------------------------------------------------------------------
# Modos de uso
# --------------------------------------------------------------------------

def modo_listar():
    lista = buscar_dispositivos()
    if not lista:
        print("No se ha encontrado ninguna tira (USB 1A86:FE07 / 1A86:FE0C).")
        explicar_sin_tira()
        return 1
    for clase, ruta in lista:
        print("%-14s %s" % (clase.nombre,
                            ruta.decode(errors="replace") if isinstance(ruta, bytes) else ruta))
    return 0


COLORES_CONTAR = [("rojo", (255, 0, 0)), ("verde", (0, 255, 0)), ("azul", (0, 0, 255)),
                  ("amarillo", (255, 255, 0)), ("morado", (255, 0, 255)),
                  ("celeste", (0, 255, 255))]


def colores_contar(n):
    """LED 1 blanco; luego bloques de 10 LEDs (1-10, 11-20...) en colores fijos."""
    colores = [COLORES_CONTAR[(i // 10) % len(COLORES_CONTAR)][1] for i in range(n)]
    colores[0] = (255, 255, 255)
    return colores


def describir_bloques(n):
    print("La tira tiene %d LEDs. Cada bloque de 10 LEDs tiene un color:" % n)
    print("  LED 1 = BLANCO (es el primero)")
    for b in range((n + 9) // 10):
        ini, fin = b * 10 + 1, min(n, b * 10 + 10)
        nombre = COLORES_CONTAR[b % len(COLORES_CONTAR)][0]
        if b == 0:
            ini = 2
        print("  LEDs %3d a %3d = %s" % (ini, fin, nombre))


def modo_contar(tira, args):
    n = tira.leds
    print()
    describir_bloques(n)
    print("Se queda así %d segundos (Ctrl+C para acabar antes)." % args.segundos)
    plano = construir_tramos(colores_contar(n), n, max(args.max_tramos, (n + 9) // 10 + 1),
                             not args.sin_limite)
    fin = time.monotonic() + args.segundos
    try:
        while time.monotonic() < fin:
            tira.enviar(plano)
            time.sleep(1)
    except KeyboardInterrupt:
        pass
    tira.negro()


def modo_prueba(tira, args):
    n = tira.leds
    lim = not args.sin_limite
    pasos = [("rojo", (255, 0, 0)), ("verde", (0, 255, 0)), ("azul", (0, 0, 255)),
             ("blanco", (255, 255, 255))]
    for nombre, c in pasos:
        log.info("Prueba: toda la tira en %s", nombre)
        tira.enviar(tramos_color_unico(n, *c, limitar=lim))
        time.sleep(1.5)
    log.info("Prueba: punto que recorre la tira del LED 1 al %d", n)
    for i in range(n):
        colores = [(0, 0, 0)] * n
        colores[i] = (255, 0, 0)
        tira.enviar(construir_tramos(colores, n, args.max_tramos, lim))
        time.sleep(max(0.02, 3.0 / n))
    log.info("Prueba: primera mitad roja, segunda azul")
    mitad = n // 2
    tira.enviar(construir_tramos([(255, 0, 0)] * mitad + [(0, 0, 255)] * (n - mitad),
                                 n, args.max_tramos, lim))
    time.sleep(2)
    tira.negro()
    log.info("Prueba terminada")


def leer_zonas(ruta):
    """Número de zonas guardado en zonas.txt, o None si no hay o no se entiende."""
    try:
        with open(ruta, encoding="utf-8-sig", errors="replace") as f:
            valor = int(f.read().split()[0])
    except (OSError, ValueError, IndexError):
        return None
    return max(1, min(valor, MAX_LEDS))


# --------------------------------------------------------------------------
# Varias tiras: tiras.txt, reparto de colores y tramos
# --------------------------------------------------------------------------

CABECERA_TIRAS = """\
# Tiras del puente Hyperion -> Robobloq. Lo crea configurar_tiras.bat.
# Se puede retocar con el Bloc de notas: el puente lo vuelve a leer en un segundo.
#
#   tira <nombre> uuid=<número de serie> hyperion=<desde>-<hasta> leds=<desde>-<hasta>[,...]
#
#   hyperion  qué colores de Hyperion le tocan a esta tira (el 1 es el primero que
#             manda Hyperion). «resto» = los que no sean de otra tira, en orden.
#   leds      en qué LEDs de la tira se pintan esos colores. Con varios tramos se pinta
#             lo mismo en todos (por ejemplo, debajo del monitor y en el borde de la
#             mesa). Al revés (por ejemplo 25-1) se pinta en sentido contrario. Los LEDs
#             que no estén en ningún tramo se quedan apagados.
"""


class TiraConfig:
    def __init__(self, nombre, uuid, hyperion="resto", tramos=None):
        self.nombre = nombre
        self.uuid = uuid.lower()
        self.hyperion = hyperion      # "resto" o (desde, hasta), contando desde 1
        self.tramos = tramos          # [(desde, hasta), ...] o None = la tira entera

    def linea(self):
        h = "resto" if self.hyperion == "resto" else "%d-%d" % self.hyperion
        partes = ["tira", self.nombre, "uuid=" + self.uuid, "hyperion=" + h]
        if self.tramos:
            partes.append("leds=" + ",".join("%d-%d" % t for t in self.tramos))
        return " ".join(partes)


def _rango(txt):
    a, sep, b = txt.strip().partition("-")
    a = int(a)
    b = int(b) if sep else a
    if a < 1 or b < 1:
        raise ValueError("los números empiezan en 1")
    return a, b


def leer_tiras(ruta):
    """Lista de TiraConfig; None si no existe el fichero. Las líneas mal
    escritas se avisan en el registro y se saltan."""
    try:
        f = open(ruta, encoding="utf-8-sig", errors="replace")
    except OSError:
        return None
    tiras = []
    with f:
        lineas = f.read().splitlines()
    nombre_fichero = os.path.basename(ruta)
    for num, linea in enumerate(lineas, 1):
        linea = linea.split("#", 1)[0].strip()
        if not linea:
            continue
        partes = linea.split()
        try:
            if partes[0].lower() != "tira" or len(partes) < 3:
                raise ValueError("tiene que empezar por «tira <nombre>»")
            campos = {}
            for p in partes[2:]:
                k, sep, v = p.partition("=")
                if not sep:
                    raise ValueError("«%s» no tiene la forma clave=valor" % p)
                campos[k.lower()] = v
            uuid = campos.get("uuid", "").lower()
            if len(uuid) != 16 or any(c not in "0123456789abcdef" for c in uuid):
                raise ValueError("uuid no válido (son 16 cifras hexadecimales)")
            h = campos.get("hyperion", "resto").lower()
            if h == "resto":
                hyperion = "resto"
            else:
                hyperion = _rango(h)
                if hyperion[0] > hyperion[1]:
                    raise ValueError("en hyperion= el primer número va antes que el segundo")
            tramos = [_rango(t) for t in campos.get("leds", "").split(",") if t.strip()]
            nueva = TiraConfig(partes[1], uuid, hyperion, tramos or None)
            if any(t.nombre == nueva.nombre or t.uuid == nueva.uuid for t in tiras):
                raise ValueError("nombre o uuid repetido")
            if hyperion == "resto" and any(t.hyperion == "resto" for t in tiras):
                raise ValueError("solo una tira puede llevar hyperion=resto")
            tiras.append(nueva)
        except (ValueError, IndexError) as e:
            log.warning("%s, línea %d: %s (la salto)", nombre_fichero, num, e)
    return tiras


def escribir_tiras(ruta, tiras):
    with open(ruta, "w", encoding="utf-8", newline="\r\n") as f:
        f.write(CABECERA_TIRAS)
        for t in tiras:
            f.write(t.linea() + "\n")


def remuestrear(colores, n):
    """Lleva una lista de colores a n colores: promedia si sobran, repite si faltan."""
    m = len(colores)
    if n <= 0 or m == 0:
        return []
    if m == n:
        return list(colores)
    if m > n:
        res = []
        for j in range(n):
            a = j * m // n
            b = max(a + 1, (j + 1) * m // n)
            g = colores[a:b]
            k = len(g)
            res.append((sum(c[0] for c in g) // k, sum(c[1] for c in g) // k,
                        sum(c[2] for c in g) // k))
        return res
    return [colores[j * m // n] for j in range(n)]


def repartir(colores, cfg):
    """Reparte los colores de Hyperion entre las tiras de tiras.txt: {nombre: colores}.
    La tira «resto» se lleva los que no son de ninguna otra, en orden circular
    empezando justo después del último colores asignado."""
    m = len(colores)
    res = {}
    usados = set()
    ultimo = 0
    for t in cfg:
        if t.hyperion != "resto":
            a, b = t.hyperion
            res[t.nombre] = colores[a - 1:b]
            usados.update(range(a, b + 1))
            ultimo = max(ultimo, b)
    for t in cfg:
        if t.hyperion == "resto":
            orden = [((ultimo + k) % m) + 1 for k in range(m)] if m else []
            res[t.nombre] = [colores[i - 1] for i in orden if i not in usados]
    return res


def colores_esperados(cfg, abiertas):
    """Cuántos colores debería mandar Hyperion con este tiras.txt (None si no se sabe)."""
    total = 0
    for t in cfg:
        if t.hyperion == "resto":
            tira = abiertas.get(t.nombre)
            if tira is None:
                return None
            total += tira.leds
        else:
            total += t.hyperion[1] - t.hyperion[0] + 1
    return total


def colores_de_tira(colores, tramos, n_leds):
    """Pinta los colores en cada tramo de LEDs (desde-hasta, al revés si desde > hasta).
    Lo que no está en ningún tramo se queda apagado."""
    salida = [(0, 0, 0)] * n_leds
    if not colores:
        return salida
    for a, b in (tramos or [(1, n_leds)]):
        paso = 1 if b >= a else -1
        leds = [i for i in range(a, b + paso, paso) if 1 <= i <= n_leds]
        for i, c in zip(leds, remuestrear(colores, len(leds))):
            salida[i - 1] = c
    return salida


def buscar_en_tiras(args, texto):
    """Uuid de la tira de tiras.txt con ese nombre, o el propio texto (prefijo de uuid)."""
    cfg = leer_tiras(args.fichero_tiras) or []
    for t in cfg:
        if t.nombre.lower() == texto.lower():
            return t.uuid
    return texto.lower()


def modo_info(args):
    tiras, _ = abrir_varias(args)
    if not tiras:
        print("No se ha encontrado ninguna tira.")
        explicar_sin_tira()
        return 1
    nombres = {t.uuid: t.nombre for t in (leer_tiras(args.fichero_tiras) or [])}
    print()
    for u, tira in tiras.items():
        v = tira.info["version"]
        print("Tira %s: %d LEDs, %d\", firmware %d.%d.%d, número de serie (uuid) %s"
              % ("«%s»" % nombres[u] if u in nombres else "sin nombre", tira.leds,
                 tira.info["pulgadas"], v[0], v[1], v[2], u))
        tira.t.cerrar()
    return 0


def modo_invertir(args):
    cfg = leer_tiras(args.fichero_tiras)
    if not cfg:
        print("No hay tiras configuradas (%s). Ejecuta antes configurar_tiras.bat."
              % os.path.basename(args.fichero_tiras))
        return 1
    for t in cfg:
        if t.nombre.lower() == args.invertir.lower():
            if not t.tramos:
                print("La tira «%s» no tiene tramos que invertir." % t.nombre)
                return 1
            t.tramos = [(b, a) for a, b in t.tramos]
            escribir_tiras(args.fichero_tiras, cfg)
            print("Tira «%s» invertida: leds=%s" % (t.nombre, ",".join("%d-%d" % x for x in t.tramos)))
            print("Si el puente está en marcha, el cambio se aplica en un segundo.")
            return 0
    print("No hay ninguna tira llamada «%s» en %s." % (args.invertir, os.path.basename(args.fichero_tiras)))
    return 1


class Mantener:
    """Reenvía cada poco lo último pintado en cada tira, para que no se apague
    mientras el asistente espera una respuesta."""

    def __init__(self):
        self.planos = {}
        self.lock = threading.Lock()
        self.fin = threading.Event()
        self.hilo = threading.Thread(target=self._bucle, daemon=True)
        self.hilo.start()

    def pintar(self, tira, colores, limitar=True):
        plano = construir_tramos(colores, tira.leds, MAX_LEDS, limitar)
        with self.lock:
            self.planos[id(tira)] = (tira, plano)
            tira.enviar(plano)

    def _bucle(self):
        while not self.fin.wait(0.8):
            with self.lock:
                for tira, plano in list(self.planos.values()):
                    try:
                        tira.enviar(plano)
                        tira.vaciar_entrada()
                    except Exception:
                        pass

    def parar(self):
        self.fin.set()
        self.hilo.join(2)


def _pregunta_numero(texto, minimo, maximo, defecto=None):
    while True:
        extra = " [%d]" % defecto if defecto is not None else ""
        r = input("%s%s: " % (texto, extra)).strip()
        if not r and defecto is not None:
            return defecto
        try:
            v = int(r)
        except ValueError:
            print("  Escribe un número.")
            continue
        if minimo <= v <= maximo:
            return v
        print("  Tiene que estar entre %d y %d." % (minimo, maximo))


def _pregunta_si(texto, defecto=True):
    while True:
        r = input("%s %s: " % (texto, "[S/n]" if defecto else "[s/N]")).strip().lower()
        if not r:
            return defecto
        if r in ("s", "si", "sí", "y", "yes"):
            return True
        if r in ("n", "no"):
            return False
        print("  Contesta s o n.")


def _apagadas(n):
    return [(0, 0, 0)] * n


def modo_configurar(args):
    """Asistente: reconoce las dos tiras, elige los tramos de la barra y escribe tiras.txt."""
    print()
    print("CONFIGURAR LAS TIRAS")
    print("Si tienes abierta la ventana de iniciar_puente.bat, ciérrala antes.")
    print()
    encontradas, _ = abrir_varias(args)
    tiras = list(encontradas.values())
    if not tiras:
        print("No veo ninguna tira.")
        explicar_sin_tira()
        return 1
    if len(tiras) < 2:
        print("Solo veo 1 tira. Enchufa las dos (cada una en su USB) y vuelve a ejecutar esto.")
        for t in tiras:
            t.t.cerrar()
        return 1
    print("Veo %d tiras." % len(tiras))
    m = Mantener()
    try:
        for t in tiras:
            m.pintar(t, _apagadas(t.leds))

        # 1) Qué tira es cada una
        colores_id = [("ROJO", (255, 0, 0)), ("VERDE", (0, 255, 0)), ("AZUL", (0, 0, 255)),
                      ("AMARILLO", (255, 255, 0))]
        papel = {}
        for i, t in enumerate(tiras):
            nombre_color, c = colores_id[i % len(colores_id)]
            m.pintar(t, [c] * t.leds)
            print()
            print("Ahora está encendida en %s una tira de %d LEDs (número de serie %s)."
                  % (nombre_color, t.leds, t.uuid))
            print("  1 = la de los lados y arriba del monitor")
            print("  2 = la barra nueva de abajo")
            print("  0 = no usarla")
            while True:
                r = _pregunta_numero("¿Cuál es?", 0, 2)
                if r and r in papel.values():
                    print("  Esa ya la has elegido para otra tira.")
                    continue
                break
            papel[t.uuid] = r
            m.pintar(t, _apagadas(t.leds))
        lados = next((t for t in tiras if papel.get(t.uuid) == 1), None)
        barra = next((t for t in tiras if papel.get(t.uuid) == 2), None)
        if lados is None or barra is None:
            print("\nHace falta elegir una tira 1 y una tira 2. Vuelve a ejecutar el asistente.")
            return 1
        n = barra.leds

        # 2) Sentido: ¿empiezan las dos por el mismo lado?
        primero = [(255, 255, 255)] + [(0, 0, 0)] * (lados.leds - 1)
        m.pintar(lados, primero)
        m.pintar(barra, [(255, 255, 255)] + [(0, 0, 0)] * (n - 1))
        print()
        print("Coloca la barra donde va a ir (puedes sujetarla con cinta de carrocero).")
        print("Ahora hay un LED BLANCO encendido en cada tira: es su LED 1, el principio.")
        mismo_lado = _pregunta_si("¿Están los dos LEDs blancos en el mismo lado "
                                  "(los dos a la izquierda o los dos a la derecha)?", True)
        m.pintar(lados, _apagadas(lados.leds))

        # 3) Tramos de la barra
        while True:
            m.pintar(barra, colores_contar(n))
            print()
            print("La barra se pinta ahora en bloques de 10 LEDs para que veas qué número tiene cada uno:")
            describir_bloques(n)
            a1 = _pregunta_numero("Primer LED que queda debajo del monitor", 1, n, 1)
            b1 = _pregunta_numero("Último LED que queda debajo del monitor", 1, n, n)
            if b1 < a1:
                a1, b1 = b1, a1
            tramos = [(a1, b1)]
            if _pregunta_si("¿Pones también un trozo en el borde de la mesa?", False):
                a2 = _pregunta_numero("Primer LED del borde de la mesa", 1, n)
                b2 = _pregunta_numero("Último LED del borde de la mesa", 1, n)
                if b2 < a2:
                    a2, b2 = b2, a2
                if a2 <= b1 and a1 <= b2:
                    print("  Los dos trozos no pueden compartir LEDs. Vamos otra vez.")
                    continue
                tramos.append((a2, b2))
            vista = _apagadas(n)
            for i in range(a1, b1 + 1):
                vista[i - 1] = (0, 255, 0)
            if len(tramos) > 1:
                for i in range(tramos[1][0], tramos[1][1] + 1):
                    vista[i - 1] = (0, 0, 255)
            m.pintar(barra, vista)
            print("Ahora: VERDE = debajo del monitor%s; apagado = lo demás."
                  % (", AZUL = borde de la mesa" if len(tramos) > 1 else ""))
            if _pregunta_si("¿Está bien?", True):
                break

        # Hyperion manda la parte de abajo desde el final de la tira de los lados hacia
        # su principio: si las dos empiezan por el mismo lado, la barra va al revés.
        if mismo_lado:
            tramos[0] = (tramos[0][1], tramos[0][0])

        # 4) El trozo de la mesa, en el mismo sentido que el del monitor
        if len(tramos) > 1:
            while True:
                print()
                print("Ahora un punto rojo recorre a la vez el trozo del monitor y el de la mesa.")
                l1 = abs(tramos[0][1] - tramos[0][0]) + 1
                for paso in range(l1):
                    vista = _apagadas(n)
                    for a, b in tramos:
                        sentido = 1 if b >= a else -1
                        largo = abs(b - a) + 1
                        k = paso * largo // l1
                        vista[a + sentido * k - 1] = (255, 0, 0)
                    m.pintar(barra, vista)
                    time.sleep(max(0.05, 4.0 / l1))
                if _pregunta_si("¿Los dos puntos iban hacia el mismo lado?", True):
                    break
                tramos[1] = (tramos[1][1], tramos[1][0])
                print("  Le doy la vuelta al trozo de la mesa. Míralo otra vez.")

        # 5) Guardar
        abajo = abs(tramos[0][1] - tramos[0][0]) + 1
        cfg = [TiraConfig("lados", lados.uuid, "resto", [(1, lados.leds)]),
               TiraConfig("barra", barra.uuid, (lados.leds + 1, lados.leds + abajo), tramos)]
        escribir_tiras(args.fichero_tiras, cfg)
        m.pintar(barra, _apagadas(n))
        total = lados.leds + abajo
        print()
        print("LISTO. Guardado en %s:" % os.path.basename(args.fichero_tiras))
        for t in cfg:
            print("   " + t.linea())
        print()
        print("Ahora, en Hyperion (en la instancia de siempre, Hardware LED):")
        print("  1. Controlador LED: el mismo de siempre (udpraw, 127.0.0.1, puerto %d)." % args.puerto)
        print("  2. Número de LEDs: %d (los %d de los lados más %d de abajo)." % (total, lados.leds, abajo))
        print("  3. Distribución de LEDs: deja izquierda, arriba y derecha como estaban")
        print("     y pon ABAJO = %d." % abajo)
        print("  4. En el dibujo, el LED 1 tiene que seguir en el mismo sitio que antes")
        print("     (el principio de la tira de los lados). Si se ha movido, cambia la")
        print("     «Posición de entrada» sumando o restando %d hasta que vuelva a su sitio." % abajo)
        print("  5. Guarda y prueba con la pantalla de prueba de la guía (el punto que da")
        print("     la vuelta). Si abajo va al revés, doble clic en invertir_barra.bat.")
        return 0
    except (EOFError, KeyboardInterrupt):
        print("\nAsistente cancelado; no se ha guardado nada.")
        return 1
    finally:
        m.parar()
        for t in tiras:
            try:
                t.negro()
                t.t.cerrar()
            except Exception:
                pass


def modo_puente(args):
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.bind((args.escuchar, args.puerto))
    log.info("Puente Hyperion -> tira Robobloq, versión %s", __version__)
    log.info("Esperando a Hyperion (udpraw) en UDP %s:%d", args.escuchar, args.puerto)

    intervalo = 1.0 / max(1, args.fps)
    abiertas = {}        # nombre de la tira -> Tira ("" en el modo de una sola tira)
    ignoradas = {}       # dispositivos que no son de tiras.txt -> hasta cuándo no preguntarles
    estado = {"cfg": None, "firma": "?", "revisado": 0.0}
    aviso_sin_tira = 0.0
    ultimo_intento = -10.0
    ultimo_envio = 0.0
    ultimo_dato = time.monotonic()
    apagada = True
    datos = None
    recibiendo = False
    avisados = set()
    zonas = {"valor": args.max_tramos, "firma": None, "revisado": 0.0}

    def revisar_zonas(forzar=False):
        """zonas.txt (lo escriben zonas_34.bat / zonas_60.bat) manda sobre --max-tramos.
        Se mira como mucho una vez por segundo; el cambio se aplica al momento."""
        ahora = time.monotonic()
        if not forzar and ahora - zonas["revisado"] < 1.0:
            return
        zonas["revisado"] = ahora
        ruta = args.fichero_zonas
        try:
            st = os.stat(ruta)
            firma = (st.st_mtime, st.st_size)
        except OSError:
            firma = None
        if firma == zonas["firma"] and not forzar:
            return
        zonas["firma"] = firma
        nuevo = leer_zonas(ruta) if firma else None
        if nuevo is None:
            nuevo = args.max_tramos
        if nuevo != zonas["valor"] or forzar:
            zonas["valor"] = nuevo
            log.info("Zonas de color por envío: %d%s", nuevo,
                     " (de %s)" % os.path.basename(ruta) if firma else " (por defecto)")

    def cerrar(nombre, apagar=True):
        tira = abiertas.pop(nombre, None)
        if tira is None:
            return
        if apagar:
            try:
                tira.negro()
            except Exception:
                pass
        try:
            tira.t.cerrar()
        except Exception:
            pass

    def revisar_tiras(forzar=False):
        """tiras.txt (lo escribe configurar_tiras.bat) dice qué tiras hay y qué pinta
        cada una. Se mira como mucho una vez por segundo; los cambios de tramos se
        aplican al momento y si cambian las tiras, se vuelven a abrir."""
        ahora = time.monotonic()
        if not forzar and ahora - estado["revisado"] < 1.0:
            return
        estado["revisado"] = ahora
        ruta = args.fichero_tiras
        try:
            st = os.stat(ruta)
            firma = (st.st_mtime, st.st_size)
        except OSError:
            firma = None
        if firma == estado["firma"] and not forzar:
            return
        estado["firma"] = firma
        nueva = leer_tiras(ruta) if firma else None
        if nueva is not None and not nueva:
            log.warning("%s no tiene ninguna tira válida: uso una sola tira",
                        os.path.basename(ruta))
            nueva = None
        vieja = estado["cfg"]

        def huella(c):
            return None if c is None else sorted((t.nombre, t.uuid) for t in c)

        cambio = huella(nueva) != huella(vieja)
        if cambio or forzar:
            if cambio:
                for nombre in list(abiertas):
                    cerrar(nombre)
                ignoradas.clear()
            if nueva is None:
                log.info("Modo de una sola tira")
            else:
                log.info("Modo de varias tiras (%s): %s", os.path.basename(ruta),
                         "; ".join(t.linea()[5:] for t in nueva))
        elif nueva is not None:
            log.info("Tramos actualizados (%s)", os.path.basename(ruta))
        estado["cfg"] = nueva

    def buscar_tiras():
        cfg = estado["cfg"]
        ahora = time.monotonic()
        if cfg is None:
            tira = abrir_tira(args)
            if tira is not None:
                abiertas[""] = tira
                if args.brillo:
                    tira.brillo(args.brillo)
            return
        faltan = {t.uuid: t.nombre for t in cfg if t.nombre not in abiertas}
        if not faltan:
            return
        en_uso = {t.clave for t in abiertas.values()}
        en_uso |= {k for k, hasta in ignoradas.items() if hasta > ahora}
        nuevas, descartadas = abrir_varias(args, quiero=set(faltan), claves_en_uso=en_uso,
                                           uuids_en_uso={t.uuid for t in abiertas.values()})
        for k in descartadas:
            ignoradas[k] = ahora + 60
        for u, tira in nuevas.items():
            abiertas[faltan[u]] = tira
            log.info("Tira «%s» conectada: %d LEDs", faltan[u], tira.leds)
            if args.brillo:
                tira.brillo(args.brillo)

    revisar_zonas(forzar=True)
    revisar_tiras(forzar=True)

    def recibir(timeout):
        # Con timeout 0 el socket queda en modo no bloqueante y, si no hay nada,
        # Windows/Linux lanzan BlockingIOError (WinError 10035) en vez de timeout.
        sock.settimeout(timeout)
        try:
            d, _ = sock.recvfrom(65535)
        except (socket.timeout, BlockingIOError, InterruptedError, ConnectionResetError):
            return None
        # quedarse solo con el más reciente
        sock.setblocking(False)
        try:
            while True:
                d, _ = sock.recvfrom(65535)
        except (BlockingIOError, ConnectionResetError, OSError):
            pass
        return d

    try:
        while True:
            if args.fichero_parada and os.path.exists(args.fichero_parada):
                log.info("Parada pedida por el servicio de Windows")
                break
            revisar_zonas()
            revisar_tiras()
            cfg = estado["cfg"]
            esperadas = 1 if cfg is None else len(cfg)
            if len(abiertas) < esperadas and time.monotonic() - ultimo_intento >= 3.0:
                ultimo_intento = time.monotonic()
                try:
                    buscar_tiras()
                except Exception as e:
                    if time.monotonic() - aviso_sin_tira > 30:
                        log.warning("%s", e)
                        aviso_sin_tira = time.monotonic()
                if cfg is not None and 0 < len(abiertas) < esperadas \
                        and time.monotonic() - aviso_sin_tira > 30:
                    log.warning("Falta la tira %s; sigo con las demás y la busco cada 3 s",
                                ", ".join("«%s»" % t.nombre for t in cfg if t.nombre not in abiertas))
                    aviso_sin_tira = time.monotonic()
            if not abiertas:
                if time.monotonic() - aviso_sin_tira > 30:
                    log.warning("Tira no encontrada; reintento cada 3 s")
                    aviso_sin_tira = time.monotonic()
                recibir(3.0)  # descarta lo que llegue mientras tanto
                continue

            nuevo = recibir(0.5)
            ahora = time.monotonic()
            if nuevo is not None:
                n = len(nuevo) // 3
                if not recibiendo:
                    log.info("Llegan colores de Hyperion: %d LEDs por paquete", n)
                    recibiendo = True
                if cfg is None:
                    esperado = abiertas[""].leds
                else:
                    esperado = colores_esperados(cfg, abiertas)
                if esperado is not None and n != esperado and n not in avisados:
                    avisados.add(n)
                    log.warning("Hyperion manda %d colores y se esperan %d: en Hyperion pon "
                                "«Hardware LED count» = %d (funciona igual, pero se reparte)",
                                n, esperado, esperado)
                datos = nuevo
                ultimo_dato = ahora
            elif recibiendo and ahora - ultimo_dato > 30:
                log.info("No llegan colores de Hyperion desde hace 30 s "
                         "(normal si Hyperion está parado o la imagen no cambia)")
                recibiendo = False
            if nuevo is None and args.apagar_tras and not apagada and ahora - ultimo_dato > args.apagar_tras:
                log.info("Sin datos de Hyperion en %d s: apago la tira", args.apagar_tras)
                datos = None
                for tira in list(abiertas.values()):
                    try:
                        tira.negro()
                    except Exception:
                        pass
                apagada = True
                continue
            if datos is None:
                continue

            espera = intervalo - (ahora - ultimo_envio)
            if espera > 0:
                time.sleep(espera)
                mas = recibir(0)
                if mas is not None:
                    datos = mas

            util = len(datos) - len(datos) % 3
            colores = [tuple(datos[i:i + 3]) for i in range(0, util, 3)]
            datos = None
            limitar = not args.sin_limite
            if cfg is None:
                planos = {"": construir_tramos(colores, abiertas[""].leds, zonas["valor"], limitar)}
            else:
                partes = repartir(colores, cfg)
                planos = {}
                for t in cfg:
                    tira = abiertas.get(t.nombre)
                    if tira is None:
                        continue
                    pintados = colores_de_tira(partes.get(t.nombre, []), t.tramos, tira.leds)
                    planos[t.nombre] = construir_tramos(pintados, tira.leds, zonas["valor"], limitar)
            for nombre, plano in planos.items():
                tira = abiertas.get(nombre)
                if tira is None:
                    continue
                try:
                    tira.enviar(plano)
                    tira.vaciar_entrada()
                except Exception as e:
                    log.warning("Se perdió la tira%s (%s); reconectando",
                                " «%s»" % nombre if nombre else "", e)
                    cerrar(nombre, apagar=False)
            ultimo_envio = time.monotonic()
            apagada = False
    except KeyboardInterrupt:
        log.info("Parando")
    finally:
        for nombre in list(abiertas):
            cerrar(nombre)
        sock.close()
    return 0


def main(argv=None):
    p = argparse.ArgumentParser(
        description="Puente Hyperion (udpraw) -> tira LED Robobloq / DX Light por USB")
    p.add_argument("--puerto", type=int, default=5568,
                   help="puerto UDP donde escucha (el mismo que en Hyperion). Por defecto 5568")
    p.add_argument("--escuchar", default="127.0.0.1",
                   help="IP donde escuchar. Por defecto 127.0.0.1 (Hyperion en este mismo PC); "
                        "0.0.0.0 si Hyperion está en otro equipo de la red")
    p.add_argument("--leds", type=int,
                   help="nº de LEDs de la tira (si no, se pregunta a la tira)")
    p.add_argument("--max-tramos", type=int, default=34,
                   help="tramos de color por trama (34 = lo que usan DX Light y OpenRGB); "
                        "si existe zonas.txt, manda lo que diga ese fichero")
    p.add_argument("--fichero-zonas", metavar="FICHERO",
                   default=os.path.join(os.path.dirname(os.path.abspath(__file__)), "zonas.txt"),
                   help="fichero con el nº de zonas, que se puede cambiar en marcha "
                        "(lo escriben zonas_34.bat y zonas_60.bat)")
    p.add_argument("--fps", type=int, default=30, help="envíos por segundo como máximo")
    p.add_argument("--brillo", type=int, help="brillo de la tira 1-255 al conectar")
    p.add_argument("--sin-limite", action="store_true",
                   help="no limitar R+G+B a 255 por LED (ojo con el consumo del USB)")
    p.add_argument("--apagar-tras", type=int, default=0,
                   help="apagar si Hyperion deja de mandar N segundos (0 = nunca)")
    p.add_argument("--dispositivo",
                   help="forzar ruta: /dev/hidraw0, COM5, /dev/ttyACM0 o ruta HID de hidapi")
    p.add_argument("--firmware-antiguo", action="store_true",
                   help="forzar el modo de firmware <= 1.0.2")
    p.add_argument("--listar", action="store_true", help="listar tiras conectadas y salir")
    p.add_argument("--info", action="store_true", help="mostrar datos de la tira y salir")
    p.add_argument("--prueba", action="store_true", help="secuencia de colores de prueba y salir")
    p.add_argument("--contar", action="store_true",
                   help="pinta la tira en bloques de 10 LEDs de colores para contarlos y salir")
    p.add_argument("--segundos", type=int, default=90,
                   help="cuánto dura --contar (por defecto 90 s; Ctrl+C para acabar antes)")
    p.add_argument("--simular", type=int, nargs="?", const=1, default=0, metavar="N",
                   help="sin hardware: N tiras simuladas (1 si no se indica); muestra las tramas")
    p.add_argument("--fichero-tiras", metavar="FICHERO",
                   default=os.path.join(os.path.dirname(os.path.abspath(__file__)), "tiras.txt"),
                   help="fichero con las tiras y sus tramos (lo escribe --configurar); "
                        "si no existe, se usa una sola tira")
    p.add_argument("--configurar", action="store_true",
                   help="asistente para dos tiras: reconoce cada una y elige sus tramos")
    p.add_argument("--invertir", metavar="NOMBRE",
                   help="da la vuelta a los tramos de esa tira en el fichero de tiras y sale")
    p.add_argument("--tira", metavar="NOMBRE",
                   help="con --prueba o --contar: qué tira usar (nombre de tiras.txt o uuid)")
    p.add_argument("--registro", metavar="FICHERO",
                   help="guardar los mensajes en un fichero (para el arranque automático)")
    p.add_argument("--fichero-parada", metavar="FICHERO",
                   help="si aparece este fichero, apaga la tira y termina (lo usa el servicio)")
    p.add_argument("-v", "--detalle", action="store_true", help="más mensajes")
    args = p.parse_args(argv)

    nivel = logging.DEBUG if args.detalle else logging.INFO
    formato = "%(asctime)s %(levelname)s %(message)s"
    if args.registro:
        from logging.handlers import RotatingFileHandler
        manejador = RotatingFileHandler(args.registro, maxBytes=1000000, backupCount=1,
                                        encoding="utf-8")
        manejador.setFormatter(logging.Formatter(formato, "%Y-%m-%d %H:%M:%S"))
        logging.basicConfig(level=nivel, handlers=[manejador])
    else:
        logging.basicConfig(level=nivel, format=formato, datefmt="%H:%M:%S")

    if args.listar:
        return modo_listar()
    if args.invertir:
        return modo_invertir(args)
    if args.configurar:
        return modo_configurar(args)
    if args.info and not (args.prueba or args.contar):
        return modo_info(args)

    if args.info or args.prueba or args.contar:
        tira = abrir_tira(args, buscar_en_tiras(args, args.tira) if args.tira else None)
        if tira is None:
            print("No se ha encontrado la tira%s." % (" «%s»" % args.tira if args.tira else ""))
            explicar_sin_tira()
            return 1
        try:
            if args.brillo and (args.prueba or args.contar):
                tira.brillo(args.brillo)
            if args.prueba:
                modo_prueba(tira, args)
            if args.contar:
                modo_contar(tira, args)
        finally:
            tira.t.cerrar()
        return 0

    # Si algo inesperado tumba el puente, se registra y se vuelve a arrancar solo
    # (importante con el arranque automático, que no tiene ventana).
    while True:
        if args.fichero_parada and os.path.exists(args.fichero_parada):
            return 0
        try:
            return modo_puente(args)
        except KeyboardInterrupt:
            return 0
        except OSError as e:
            if getattr(e, "winerror", None) == 10048 or e.errno in (48, 98, 10048):
                log.warning("El puerto UDP %d ya lo está usando otro programa (¿hay otro puente "
                            "abierto, una ventana de iniciar_puente.bat o el servicio?). "
                            "Reintento en 10 s", args.puerto)
                time.sleep(10)
            else:
                log.exception("Error inesperado en el puente; vuelvo a arrancarlo en 3 s")
                time.sleep(3)
        except Exception:
            log.exception("Error inesperado en el puente; vuelvo a arrancarlo en 3 s")
            time.sleep(3)


if __name__ == "__main__":
    sys.exit(main())
