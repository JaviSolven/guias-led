# Tira LED Robobloq (DX Light) con Hyperion

Hyperion no tiene controlador para esta tira. Este puente se ejecuta en el PC
que tiene la tira enchufada por USB y hace de traductor:

```
Hyperion  ──UDP (udpraw)──►  robobloq_bridge.py  ──USB──►  tira LED
(en ese PC o en otro de la red)        (en el PC de la tira)
```

El protocolo se ha sacado del propio programa DX Light 3.11.0 y coincide con el
driver de la misma tira que tiene OpenRGB. Las tramas del puente se han
comparado byte a byte con las que genera el programa original y son idénticas.
Probado con la tira de verdad: 54 LEDs, firmware 1.7.3. El modo de dos tiras
(versión 1.3.0) está probado con tiras simuladas.

## Qué tira es

| USB | Tipo | Nota |
|---|---|---|
| `1A86:FE07` | HID | La normal. Fabricante «ROBOBLOQ» |
| `1A86:FE0C` | Puerto serie (115200) | Variante antigua |

En Windows, en el Administrador de dispositivos sale como «Dispositivo de
entrada USB» con `VID_1A86&PID_FE07`.

## 1. Preparar el PC de la tira

**Antes de nada, cierra DX Light** y quítalo del inicio de Windows. Si los dos
programas mandan colores a la vez, la tira parpadea.

### Windows

No hace falta instalar ninguna librería: el puente usa el soporte HID que ya
trae Windows. Solo hace falta Python.

1. Instala **Python 3** desde python.org. Deja marcadas las opciones «py
   launcher» y «Add python.exe to PATH».
2. Copia la carpeta entera a **`C:\hyperion-robobloq`**. Mejor en una ruta
   corta y sin espacios.
3. **Cierra DX Light**, también el icono junto al reloj, y quítalo del
   inicio de Windows: Administrador de tareas → Inicio → DX Light →
   Deshabilitar.
4. Doble clic en **`probar_tira.bat`**. Busca la tira, enseña sus datos (nº de
   LEDs y firmware) y hace la prueba de colores. Al final un punto rojo
   recorre la tira desde el LED 1: **apunta dónde empieza y hacia dónde va**,
   porque necesitas ese dato en Hyperion.
5. Doble clic en **`iniciar_puente.bat`** para dejar el puente funcionando con
   la ventana a la vista. Así ves los mensajes mientras configuras Hyperion.
6. Cuando todo vaya bien, cierra esa ventana y ejecuta
   **`instalar_servicio.bat`** con botón derecho → «Ejecutar como
   administrador». Instala el puente como **servicio de Windows** («Puente
   Hyperion Robobloq»):
   - Arranca solo al encender el PC, sin ninguna ventana.
   - Windows lo vuelve a arrancar si falla.
   - Se ve en `services.msc`.
   - Sus opciones quedan en `servicio.cfg` y sus mensajes en `servicio.log` y
     `puente.log`.
   - Se quita con `desinstalar_servicio.bat`.

   Si no tienes permisos de administrador, usa en su lugar
   `arranque_automatico.bat`: sin ventana, al iniciar sesión, y sin
   relanzado automático. Se quita con `quitar_arranque.bat`. No uses las dos
   opciones a la vez.

Por defecto el puente solo escucha dentro del propio PC (`127.0.0.1`). Es lo
correcto si Hyperion está en el mismo PC, y así no hace falta tocar el
firewall.

Si Hyperion está en **otro** equipo de la red:
- Cambia en `iniciar_puente.bat`, en `instalar_servicio.bat` (línea
  `OPCIONES`) y en `arranque_automatico.bat` los parámetros a
  `--puerto 5568 --escuchar 0.0.0.0`.
- Ejecuta `abrir_firewall.bat` con botón derecho → «Ejecutar como
  administrador».

| Fichero | Para qué |
|---|---|
| `probar_tira.bat` | Comprobar que se ve la tira y prueba de colores |
| `contar_leds.bat` | Pinta la tira en bloques de 10 LEDs de colores para contar los de cada lado |
| `iniciar_puente.bat` | Puente con ventana (para probar) |
| `zonas_34.bat` | Modo normal: 34 zonas de color, como DX Light (se aplica al momento) |
| `zonas_60.bat` | Modo detalle: 60 zonas, un color por LED en una tira de 54 (se aplica al momento) |
| `accesos_escritorio.bat` | Pone los dos modos como accesos directos en el escritorio |
| `instalar_servicio.bat` | Instala el puente como servicio de Windows (como administrador) |
| `desinstalar_servicio.bat` | Quita el servicio (como administrador) |
| `servicio_windows.cs` | Código del lanzador del servicio; el instalador lo compila con el .NET de Windows |
| `arranque_automatico.bat` | Alternativa sin administrador: puente sin ventana al iniciar sesión |
| `quitar_arranque.bat` | Quita esa alternativa |
| `abrir_firewall.bat` | Abrir UDP 5568 (solo si Hyperion está en otro PC; como administrador) |
| `configurar_tiras.bat` | Asistente para usar **dos tiras** (lados + barra de abajo); crea `tiras.txt` (como administrador si tienes el servicio) |
| `invertir_barra.bat` | Da la vuelta a la barra de abajo si en Hyperion va al revés (se aplica al momento) |

### Linux / Raspberry Pi

```
sudo mkdir -p /opt/hyperion-robobloq
sudo cp robobloq_bridge.py /opt/hyperion-robobloq/
sudo cp 99-robobloq.rules /etc/udev/rules.d/
sudo udevadm control --reload && sudo udevadm trigger
python3 /opt/hyperion-robobloq/robobloq_bridge.py --listar
python3 /opt/hyperion-robobloq/robobloq_bridge.py --prueba
```

En Linux no hace falta instalar nada: el puente escribe directamente en
`/dev/hidrawX`. La regla udev es para no necesitar `sudo`.

Para que arranque solo:

```
sudo cp robobloq-bridge.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now robobloq-bridge
journalctl -u robobloq-bridge -f
```

## 2. Configurar Hyperion

La guía paso a paso para novatos está en `GUIA.html`, en esta misma carpeta,
y en internet en https://javisolven.github.io/guias-led/hyperion.html (acceso
directo: `Guia en internet.url`).

En resumen:
- Instala Hyperion con el instalador de Windows de las *releases* de GitHub
  del proyecto `hyperion-project/hyperion.ng` (`Hyperion-x.y.z-Windows-x64.exe`).
- Se configura desde el navegador, en `http://localhost:8090`.
- Para que copie la pantalla de ese PC, activa la captura de pantalla de la
  plataforma: en Windows es la «DDA»; la «DirectX» está obsoleta.

En la interfaz web de Hyperion, apartado **Hardware LED**:

1. **Controlador LED**, tipo **`udpraw`** (en el grupo de red).
   - Host / IP: la IP del PC de la tira. Si Hyperion está en ese mismo PC,
     pon `127.0.0.1`.
   - Puerto: **5568**, el mismo que use el puente (`--puerto`).
   - Orden de color: **RGB**.
2. **Distribución de LEDs**: pon tantos LEDs como tiene la tira (sale en
   `--info`) y ajusta la posición de inicio y el sentido según lo que viste con
   `--prueba`.
3. Guarda. En cuanto Hyperion mande colores, la tira debe responder.

## 3. Opciones del puente

| Opción | Para qué |
|---|---|
| `--puerto 5568` | Puerto UDP. Tiene que coincidir con Hyperion |
| `--escuchar 127.0.0.1` | IP donde escucha. Pon `0.0.0.0` si Hyperion está en otro PC |
| `--contar` | Bloques de 10 LEDs de colores para contarlos (`--segundos 90`) |
| `--leds N` | Fuerza el nº de LEDs si la tira no lo dice |
| `--max-tramos 34` | Zonas de color por trama si no hay `zonas.txt` (ver abajo) |
| `--fichero-zonas` | Fichero con el nº de zonas, que se lee en marcha (por defecto `zonas.txt` junto al puente) |
| `--fps 30` | Máximo de envíos por segundo |
| `--brillo 1-255` | Brillo de la tira al conectar |
| `--sin-limite` | Quita el límite de consumo (ver abajo) |
| `--apagar-tras N` | Apaga la tira si Hyperion deja de mandar N segundos |
| `--dispositivo` | Fuerza la ruta: `/dev/hidraw0`, `COM5`... |
| `--listar` / `--info` / `--prueba` | Diagnóstico |
| `--simular` | Sin tira: enseña las tramas en pantalla |
| `-v` | Más mensajes |

## Dos cosas que conviene saber

**Zonas de color (34).** La tira no recibe un color por LED, sino tramos del
tipo «del LED 5 al 9, este color». DX Light manda como mucho 34 tramos y
OpenRGB usa el mismo límite. El puente junta los LEDs vecinos de color
parecido hasta caber en 34. En la práctica se ven 34 zonas de color alrededor
de la pantalla.

Hay dos modos, que se cambian con doble clic sin reiniciar nada:
- `zonas_34.bat`: modo normal, 34 zonas.
- `zonas_60.bat`: modo detalle, 60 zonas. En la tira de 54 LEDs con
  firmware 1.7.3 es un color por LED, y funciona.

El elegido se guarda en `zonas.txt`, que manda sobre `--max-tramos`, y se
recuerda tras reiniciar. En modo detalle se ve más brillante y con más
contraste, porque los LEDs ya no se promedian con sus vecinos; el consumo
máximo no sube. Si la tira se congela en modo detalle, vuelve a
`zonas_34.bat`.

**Límite de consumo.** DX Light limita cada LED para que R+G+B no pase de 255,
para que la tira no pida al USB más corriente de la que puede dar. El puente
hace lo mismo por defecto, así que un blanco puro sale como gris claro. Si la
tira tiene alimentación propia o aguanta más, puedes quitarlo con
`--sin-limite`. Si con eso la tira se apaga o se reinicia al ponerse en blanco,
vuelve a activarlo.

## Dos tiras: la de los lados y una barra abajo

Desde la versión 1.3.0 el puente puede manejar **dos tiras Robobloq a la vez**,
por ejemplo la de siempre en los lados y arriba del monitor, y otra igual
puesta en recto debajo. En Hyperion sigue siendo **una sola instancia** con los
cuatro lados; el puente reparte los colores entre las dos tiras.

- Cada tira se reconoce por su **número de serie** (uuid), así que da igual en
  qué USB enchufes cada una.
- De la barra puedes usar solo algunos tramos: por ejemplo, del LED 1 al 25
  debajo del monitor, del 26 al 32 apagados (la bajada hasta la mesa) y del 33
  al 54 en el borde de la mesa, copiando lo mismo que debajo del monitor.
- Si una tira se desenchufa, la otra sigue funcionando y el puente vuelve a
  coger la que falta en cuanto la enchufas.

Cómo se pone en marcha:

1. Enchufa las dos tiras, cada una en su USB de la torre.
2. Clic derecho en **`configurar_tiras.bat`** → «Ejecutar como administrador»
   (si no tienes el servicio instalado, basta con doble clic). Para el servicio
   mientras tanto y lo vuelve a arrancar al final. El asistente:
   - enciende cada tira de un color y te pregunta cuál es;
   - te pregunta si los LED 1 (el blanco) de las dos están en el mismo lado;
   - pinta la barra en bloques de 10 y te pide qué LEDs van debajo del monitor
     y, si quieres, cuáles van en el borde de la mesa;
   - te enseña cómo queda y guarda todo en `tiras.txt`.
3. En Hyperion, en la instancia de siempre (Hardware LED), cambia lo que diga el
   asistente al final: el número de LEDs (los de los lados más los de abajo) y,
   en Distribución de LEDs, el número de LEDs de abajo. El hueco de abajo
   («gap») se deja en 0: los tramos apagados los hace el puente. El LED 1 tiene
   que seguir en el mismo sitio que antes; si se ha movido, cambia la «Posición
   de entrada» sumando o restando los LEDs de abajo hasta que vuelva a su sitio.
4. Prueba con la pantalla de prueba de la guía (el punto que da la vuelta). Si
   en la barra el punto va al revés, doble clic en **`invertir_barra.bat`**.

`tiras.txt` se puede retocar con el Bloc de notas y el puente lo relee en un
segundo. Si lo borras, el puente vuelve a funcionar con una sola tira, como
antes. Para contar los LEDs de una tira concreta:
`py -3 robobloq_bridge.py --contar --tira barra`.

| Opción | Para qué |
|---|---|
| `--configurar` | El asistente de dos tiras |
| `--info` | Datos de todas las tiras enchufadas, con su número de serie |
| `--tira NOMBRE` | Con `--contar` o `--prueba`: qué tira usar (`lados`, `barra` o el uuid) |
| `--invertir NOMBRE` | Da la vuelta a los tramos de esa tira en `tiras.txt` |
| `--fichero-tiras` | Otro fichero en vez de `tiras.txt` |
| `--simular 2` | Prueba sin hardware con dos tiras simuladas |

## Si algo falla

- `--listar` no encuentra nada:
  - ¿La tira está enchufada y DX Light cerrado?
  - En el Administrador de dispositivos, ¿sale con `VID_1A86&PID_FE07`? Si
    sale como puerto COM con `PID_FE0C`, instala el soporte serie:
    `py -3 -m pip install pyserial`.
  - En Linux, ¿has copiado la regla udev?
- La tira se encuentra pero no cambia de color (Windows): instala
  `py -3 -m pip install hidapi`. El puente lo usará en lugar del soporte HID
  de Windows.
- La tira se ve con los colores cambiados: cambia el orden de color en
  Hyperion (RGB, GRB...).
- Hyperion no llega:
  - Revisa el puerto y la IP, y el firewall del PC de la tira.
  - Con `-v`, el puente escribe cada paso.
