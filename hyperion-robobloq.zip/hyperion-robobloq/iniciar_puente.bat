@echo off
rem Arranca el puente Hyperion -> tira LED con la ventana visible (para probar).
rem ANTES: cierra DX Light.
rem Si Hyperion esta en OTRO PC de la red, cambia la linea de abajo por:
rem   py -3 robobloq_bridge.py --puerto 5568 --escuchar 0.0.0.0
cd /d "%~dp0"
py -3 robobloq_bridge.py --puerto 5568
pause
