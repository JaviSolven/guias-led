@echo off
rem MODO DETALLE: 60 zonas de color (en una tira de 54 LEDs, un color por LED).
rem Se aplica al momento: no hace falta reiniciar el puente ni el servicio.
cd /d "%~dp0"
> "%~dp0zonas.txt" echo 60
echo.
echo   Tira en MODO DETALLE: 60 zonas de color (un color por LED).
echo   El puente lo aplica en un segundo. Esta ventana se cierra sola.
ping -n 4 127.0.0.1 >nul
