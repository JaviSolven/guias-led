@echo off
rem Pone en el escritorio dos accesos directos para cambiar de modo con doble clic:
rem   "Tira - modo normal (34 zonas)" y "Tira - modo detalle (60 zonas)".
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$w=New-Object -ComObject WScript.Shell; $e=[Environment]::GetFolderPath('Desktop'); foreach ($m in @(@('34','Tira - modo normal (34 zonas)'),@('60','Tira - modo detalle (60 zonas)'))) { $s=$w.CreateShortcut($e+'\'+$m[1]+'.lnk'); $s.TargetPath='%~dp0zonas_'+$m[0]+'.bat'; $s.WorkingDirectory='%~dp0'; $s.IconLocation=$env:SystemRoot+'\System32\imageres.dll,'+$(if ($m[0] -eq '34') {'101'} else {'102'}); $s.Description='Cambia la tira LED a '+$m[0]+' zonas'; $s.Save(); '  Creado en el escritorio: '+$m[1] }"
echo.
pause
